using Microsoft.AspNetCore.Mvc;
using MES360Portal.Models;
using MES360Portal.Repository;
using ClosedXML.Excel;
using System.IO;

namespace MES360Portal.Controllers
{
    public class ProductionController : Controller
    {
        private readonly TcfNftRepository _tcfNftRepository;

        public ProductionController(TcfNftRepository tcfNftRepository)
        {
            _tcfNftRepository = tcfNftRepository;
        }

        [HttpGet]
        public IActionResult TcfNft()
        {
            TcfNftFilterModel filter = new TcfNftFilterModel
            {
                Model = "ALL",
                FromDate = DateTime.Today,
                FromHour = "12",
                FromMin = "00",
                FromAmPm = "AM",
                ToDate = DateTime.Today,
                ToHour = "11",
                ToMin = "59",
                ToAmPm = "PM"
            };

            TcfNftViewModel viewModel = new TcfNftViewModel
            {
                Filter = filter
            };

            return View(viewModel);
        }

        [HttpPost]
        public IActionResult TcfNft(TcfNftFilterModel filter)
        {
            TcfNftViewModel viewModel = _tcfNftRepository.GetTcfNftReport(filter);
            return View(viewModel);
        }

        [HttpPost]
        public IActionResult ExportTcfNftExcel(TcfNftFilterModel filter)
        {
            TcfNftViewModel viewModel = _tcfNftRepository.GetTcfNftReport(filter);

            using XLWorkbook workbook = new XLWorkbook();

            IXLWorksheet worksheet = workbook.Worksheets.Add("TCF NFT Report");

            int currentRow = 1;

            worksheet.Cell(currentRow, 1).Value = "TCF NFT REPORT";
            worksheet.Range(currentRow, 1, currentRow, 9).Merge();
            worksheet.Cell(currentRow, 1).Style.Font.Bold = true;
            worksheet.Cell(currentRow, 1).Style.Font.FontSize = 16;
            worksheet.Cell(currentRow, 1).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;

            currentRow += 2;

            worksheet.Cell(currentRow, 1).Value = "Model";
            worksheet.Cell(currentRow, 2).Value = filter.Model;

            worksheet.Cell(currentRow, 4).Value = "From Date";
            worksheet.Cell(currentRow, 5).Value = filter.FromDate?.ToString("yyyy-MM-dd");

            worksheet.Cell(currentRow, 7).Value = "To Date";
            worksheet.Cell(currentRow, 8).Value = filter.ToDate?.ToString("yyyy-MM-dd");

            currentRow++;

            worksheet.Cell(currentRow, 1).Value = "Total Production";
            worksheet.Cell(currentRow, 2).Value = viewModel.Summary.TotalProduction;

            worksheet.Cell(currentRow, 4).Value = "Total NFT Vehicles";
            worksheet.Cell(currentRow, 5).Value = viewModel.Summary.TotalNftVehicles;

            worksheet.Cell(currentRow, 7).Value = "FSO (%)";
            worksheet.Cell(currentRow, 8).Value = viewModel.Summary.FsoPercentage;

            worksheet.Range(currentRow - 1, 1, currentRow, 8).Style.Font.Bold = true;

            currentRow += 2;

            worksheet.Cell(currentRow, 1).Value = "Sr.No";
            worksheet.Cell(currentRow, 2).Value = "Date";
            worksheet.Cell(currentRow, 3).Value = "Time";
            worksheet.Cell(currentRow, 4).Value = "VIN";
            worksheet.Cell(currentRow, 5).Value = "Item";
            worksheet.Cell(currentRow, 6).Value = "Defect";
            worksheet.Cell(currentRow, 7).Value = "Booked Against";
            worksheet.Cell(currentRow, 8).Value = "QA Status";
            worksheet.Cell(currentRow, 9).Value = "Reported By";

            IXLRange headerRange = worksheet.Range(currentRow, 1, currentRow, 9);
            headerRange.Style.Font.Bold = true;
            headerRange.Style.Fill.BackgroundColor = XLColor.FromHtml("#005bbb");
            headerRange.Style.Font.FontColor = XLColor.White;
            headerRange.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;

            foreach (TcfNftDetailModel item in viewModel.Details)
            {
                currentRow++;

                worksheet.Cell(currentRow, 1).Value = item.SrNo;
                worksheet.Cell(currentRow, 2).Value = item.Date;
                worksheet.Cell(currentRow, 3).Value = item.Time;
                worksheet.Cell(currentRow, 4).Value = item.Vin;
                worksheet.Cell(currentRow, 5).Value = item.Item;
                worksheet.Cell(currentRow, 6).Value = item.Defect;
                worksheet.Cell(currentRow, 7).Value = item.BookedAgainst;
                worksheet.Cell(currentRow, 8).Value = item.QaStatus;
                worksheet.Cell(currentRow, 9).Value = item.ReportedBy;
            }

            worksheet.Columns().AdjustToContents();

            using MemoryStream stream = new MemoryStream();
            workbook.SaveAs(stream);

            string fileName = $"TCF_NFT_Report_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx";

            return File(
                stream.ToArray(),
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                fileName
            );
        }
    }
}