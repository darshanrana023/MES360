using Microsoft.Data.SqlClient;
using MES360Portal.Models;
using System.Data;

namespace MES360Portal.Repository
{
    public class TcfNftRepository
    {
        private readonly IConfiguration _configuration;

        public TcfNftRepository(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public TcfNftViewModel GetTcfNftReport(TcfNftFilterModel filter)
        {
            TcfNftViewModel viewModel = new TcfNftViewModel
            {
                Filter = filter
            };

            try
            {
                DateTime fromDateTime = BuildDateTime(
                    filter.FromDate,
                    filter.FromHour,
                    filter.FromMin,
                    filter.FromAmPm,
                    true
                );

                DateTime toDateTime = BuildDateTime(
                    filter.ToDate,
                    filter.ToHour,
                    filter.ToMin,
                    filter.ToAmPm,
                    false
                );

                string model = NormalizeModel(filter.Model);

                viewModel.Summary.TotalProduction = GetTotalProduction(fromDateTime, toDateTime, model);
                viewModel.Summary.TotalNftVehicles = GetTotalNftVehicles(fromDateTime, toDateTime, model);

                if (viewModel.Summary.TotalProduction != 0)
                {
                    viewModel.Summary.FsoPercentage = Math.Round(
                        ((viewModel.Summary.TotalProduction - viewModel.Summary.TotalNftVehicles)
                        / viewModel.Summary.TotalProduction) * 100,
                        2
                    );
                }
                else
                {
                    viewModel.Summary.FsoPercentage = 0;
                }

                viewModel.Details = GetNftDetails(fromDateTime, toDateTime, model);
            }
            catch (Exception ex)
            {
                viewModel.ErrorMessage = ex.Message;
            }

            return viewModel;
        }

        private decimal GetTotalProduction(DateTime fromDateTime, DateTime toDateTime, string model)
        {
            decimal totalProduction = 0;

            string connectionString = _configuration.GetConnectionString("MESDB") ?? "";

            string query = @"
                SELECT COUNT(1)
                FROM dbo.UDA_Order
                WHERE SID_S = '54'
                  AND plant_s = '7501'
                  AND line_number_s = '1'
                  AND orderendtime_t BETWEEN @FromDateTime AND @ToDateTime
                  AND
                  (
                        ISNULL(ProductVariant_S, 'NANO') LIKE
                        CASE
                            WHEN @Model IN ('All') THEN '%'
                            WHEN @Model = 'TIAGO' THEN 'KITE'
                            ELSE @Model
                        END

                        OR

                        ProductVariant_S LIKE
                        CASE
                            WHEN @Model = 'TIAGO' THEN 'TIAGO'
                        END
                  )";

            using SqlConnection connection = new SqlConnection(connectionString);
            using SqlCommand command = new SqlCommand(query, connection);

            command.CommandType = CommandType.Text;
            command.CommandTimeout = 120;

            command.Parameters.AddWithValue("@FromDateTime", fromDateTime);
            command.Parameters.AddWithValue("@ToDateTime", toDateTime);
            command.Parameters.AddWithValue("@Model", model);

            connection.Open();

            object? result = command.ExecuteScalar();

            if (result != null && result != DBNull.Value)
            {
                totalProduction = Convert.ToDecimal(result);
            }

            return totalProduction;
        }

        private decimal GetTotalNftVehicles(DateTime fromDateTime, DateTime toDateTime, string model)
        {
            decimal totalNftVehicles = 0;

            string connectionString = _configuration.GetConnectionString("MESDB") ?? "";

            using SqlConnection connection = new SqlConnection(connectionString);
            using SqlCommand command = new SqlCommand("SAN_NFTCount", connection);

            command.CommandType = CommandType.StoredProcedure;
            command.CommandTimeout = 120;

            command.Parameters.AddWithValue("@start", ToSqlDateString(fromDateTime));
            command.Parameters.AddWithValue("@end", ToSqlDateString(toDateTime));
            command.Parameters.AddWithValue("@variant", model);

            connection.Open();

            object? result = command.ExecuteScalar();

            if (result != null && result != DBNull.Value)
            {
                totalNftVehicles = Convert.ToDecimal(result);
            }

            return totalNftVehicles;
        }

        private List<TcfNftDetailModel> GetNftDetails(DateTime fromDateTime, DateTime toDateTime, string model)
        {
            List<TcfNftDetailModel> details = new List<TcfNftDetailModel>();

            string connectionString = _configuration.GetConnectionString("MESDB") ?? "";

            using SqlConnection connection = new SqlConnection(connectionString);
            using SqlCommand command = new SqlCommand("SAN_NFT", connection);

            command.CommandType = CommandType.StoredProcedure;
            command.CommandTimeout = 120;

            command.Parameters.AddWithValue("@start", ToSqlDateString(fromDateTime));
            command.Parameters.AddWithValue("@end", ToSqlDateString(toDateTime));
            command.Parameters.AddWithValue("@Model", model);

            using SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable dataTable = new DataTable();

            adapter.Fill(dataTable);

            int counter = 1;

            foreach (DataRow row in dataTable.Rows)
            {
                TcfNftDetailModel item = new TcfNftDetailModel
                {
                    SrNo = GetInt(row, "Sr.No.", "SrNo", "Sr.No", "SrNo."),
                    Date = GetString(row, "Date"),
                    Time = GetString(row, "Time"),
                    Vin = GetString(row, "VIN", "Vin"),
                    Item = GetString(row, "Item"),
                    Defect = GetString(row, "Defect"),
                    BookedAgainst = GetString(row, "Booked Against", "BookedAgainst", "Booked_Against"),
                    QaStatus = GetString(row, "Current QA Status", "QA Status", "QAStatus", "QaStatus", "QA_Status", "Status"),
                    ReportedBy = GetString(row, "Reported By", "ReportedBy", "Reported_By")
                };

                if (item.SrNo == 0)
                {
                    item.SrNo = counter;
                }

                details.Add(item);
                counter++;
            }

            return details;
        }

        private DateTime BuildDateTime(DateTime? date, string hour, string min, string amPm, bool isFromDate)
        {
            DateTime selectedDate = date ?? DateTime.Today;

            int hh = Convert.ToInt32(hour);
            int mm = Convert.ToInt32(min);

            if (amPm == "PM" && hh != 12)
            {
                hh += 12;
            }

            if (amPm == "AM" && hh == 12)
            {
                hh = 0;
            }

            return new DateTime(
                selectedDate.Year,
                selectedDate.Month,
                selectedDate.Day,
                hh,
                mm,
                isFromDate ? 0 : 59
            );
        }

        private string NormalizeModel(string? model)
        {
            if (string.IsNullOrWhiteSpace(model))
            {
                return "All";
            }

            if (model.Trim().ToUpper() == "ALL")
            {
                return "All";
            }

            return model.Trim();
        }

        private string ToSqlDateString(DateTime dateTime)
        {
            return dateTime.ToString("yyyy-MM-dd HH:mm:ss.fff");
        }

        private string GetString(DataRow row, params string[] columnNames)
        {
            foreach (string columnName in columnNames)
            {
                DataColumn? matchedColumn = row.Table.Columns
                    .Cast<DataColumn>()
                    .FirstOrDefault(c =>
                        string.Equals(
                            c.ColumnName.Trim(),
                            columnName.Trim(),
                            StringComparison.OrdinalIgnoreCase
                        )
                    );

                if (matchedColumn != null)
                {
                    return row[matchedColumn] == DBNull.Value
                        ? ""
                        : row[matchedColumn]?.ToString() ?? "";
                }
            }

            return "";
        }

        private int GetInt(DataRow row, params string[] columnNames)
        {
            foreach (string columnName in columnNames)
            {
                DataColumn? matchedColumn = row.Table.Columns
                    .Cast<DataColumn>()
                    .FirstOrDefault(c =>
                        string.Equals(
                            c.ColumnName.Trim(),
                            columnName.Trim(),
                            StringComparison.OrdinalIgnoreCase
                        )
                    );

                if (matchedColumn != null)
                {
                    if (row[matchedColumn] == DBNull.Value)
                    {
                        return 0;
                    }

                    return Convert.ToInt32(row[matchedColumn]);
                }
            }

            return 0;
        }
    }
}