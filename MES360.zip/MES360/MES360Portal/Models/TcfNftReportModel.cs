namespace MES360Portal.Models
{
    public class TcfNftFilterModel
    {
        public string Model { get; set; } = "ALL";

        public DateTime? FromDate { get; set; }
        public string FromHour { get; set; } = "12";
        public string FromMin { get; set; } = "00";
        public string FromAmPm { get; set; } = "AM";

        public DateTime? ToDate { get; set; }
        public string ToHour { get; set; } = "11";
        public string ToMin { get; set; } = "59";
        public string ToAmPm { get; set; } = "PM";
    }

    public class TcfNftSummaryModel
    {
        public decimal TotalProduction { get; set; }
        public decimal TotalNftVehicles { get; set; }
        public decimal FsoPercentage { get; set; }
    }

    public class TcfNftDetailModel
    {
        public int SrNo { get; set; }
        public string Date { get; set; } = "";
        public string Time { get; set; } = "";
        public string Vin { get; set; } = "";
        public string Item { get; set; } = "";
        public string Defect { get; set; } = "";
        public string BookedAgainst { get; set; } = "";
        public string QaStatus { get; set; } = "";
        public string ReportedBy { get; set; } = "";
    }

    public class TcfNftViewModel
    {
        public TcfNftFilterModel Filter { get; set; } = new TcfNftFilterModel();
        public TcfNftSummaryModel Summary { get; set; } = new TcfNftSummaryModel();
        public List<TcfNftDetailModel> Details { get; set; } = new List<TcfNftDetailModel>();
        public string ErrorMessage { get; set; } = "";
    }
}