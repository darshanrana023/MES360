using Microsoft.AspNetCore.Mvc;

namespace MES360Portal.Controllers
{
    public class ProductionController : Controller
    {
        public IActionResult TcfNft()
        {
            return View();
        }
    }
}