using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace MES360Portal.Controllers
{
    [Authorize]
    public class HelpController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }
    }
}