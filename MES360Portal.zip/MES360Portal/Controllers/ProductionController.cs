using System;
using System.Linq;
using System.Text;
using MES360Portal.Models;
using MES360Portal.Repository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace MES360Portal.Controllers
{
    [Authorize]
    public class ProductionController : Controller
    {
        private readonly TcfNftRepository _tcfNftRepository;
        private readonly BiwVinGenerationRepository _biwVinGenerationRepository;
        private readonly TcfVinGenerationRepository _tcfVinRepository;
        private readonly JisReportRepository _jisReportRepository;
        private readonly LiveWIPReportTestRepository _liveWIPReportTestRepository;
        private readonly LiveWIPReportRepository _liveWIPReportRepository;
        private readonly DailyOrderSummaryRepository _dailyOrderSummaryRepository;
        private readonly DailyOrderSummaryPartwiseRepository _dailyOrderSummaryPartwiseRepository;
        private readonly TcfEolDrrRepository _tcfEolDrrRepository;
        private readonly IlcrReportRepository _ilcrReportRepository;
        private readonly OrderInMESRepository _orderInMESRepository;
        private readonly DailyProductionReportRepository _dailyProductionReportRepository;
        private readonly TcfOemDataReportRepository _tcfOemDataReportRepository;
        private readonly QGWiseTrackingReportRepository _qgWiseTrackingReportRepository;

        public ProductionController(
            TcfNftRepository tcfNftRepository,
            BiwVinGenerationRepository biwVinGenerationRepository,
            TcfVinGenerationRepository tcfVinRepository,
            JisReportRepository jisReportRepository,
            LiveWIPReportTestRepository liveWIPReportTestRepository,
            LiveWIPReportRepository liveWIPReportRepository,
            DailyOrderSummaryRepository dailyOrderSummaryRepository,
            DailyOrderSummaryPartwiseRepository dailyOrderSummaryPartwiseRepository,
            TcfEolDrrRepository tcfEolDrrRepository,
            IlcrReportRepository ilcrReportRepository,
            OrderInMESRepository orderInMESRepository,
            DailyProductionReportRepository dailyProductionReportRepository,
            QGWiseTrackingReportRepository qgWiseTrackingReportRepository,
            TcfOemDataReportRepository tcfOemDataReportRepository
            )
        {
            _tcfNftRepository = tcfNftRepository;
            _biwVinGenerationRepository = biwVinGenerationRepository;
            _tcfVinRepository = tcfVinRepository;
            _jisReportRepository = jisReportRepository;
            _liveWIPReportTestRepository = liveWIPReportTestRepository;
            _liveWIPReportRepository = liveWIPReportRepository;
            _dailyOrderSummaryRepository = dailyOrderSummaryRepository;
            _dailyOrderSummaryPartwiseRepository = dailyOrderSummaryPartwiseRepository;
            _tcfEolDrrRepository = tcfEolDrrRepository;
            _ilcrReportRepository = ilcrReportRepository;
            _orderInMESRepository = orderInMESRepository;
            _dailyProductionReportRepository = dailyProductionReportRepository;
            _qgWiseTrackingReportRepository = qgWiseTrackingReportRepository;
            _tcfOemDataReportRepository = tcfOemDataReportRepository;
        }

        #region Daily Production Report Actions

        [HttpGet]
        public IActionResult DailyProductionReport()
        {
            var filter = new DailyProductionFilterModel
            {
                Model = "ALL",
                FromDate = new DateTime(2026, 8, 1),
                FromHour = "06",
                FromMin = "30",
                FromAmPm = "AM",
                ToDate = new DateTime(2026, 8, 31),
                ToHour = "11",
                ToMin = "59",
                ToAmPm = "PM"
            };

            var viewModel = _dailyProductionReportRepository.GetDailyProductionReport(filter);
            return View(viewModel);
        }

        [HttpPost]
        public IActionResult DailyProductionReport(DailyProductionFilterModel filter)
        {
            var viewModel = _dailyProductionReportRepository.GetDailyProductionReport(filter);
            return View(viewModel);
        }

        [HttpPost]
        public IActionResult GetDailyProductionReportDataJson([FromBody] DailyProductionFilterModel filter)
        {
            try
            {
                var viewModel = _dailyProductionReportRepository.GetDailyProductionReport(filter);
                return Json(new { success = true, data = viewModel });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        #endregion

        #region Order in MES Report Actions

        [HttpGet]
        public IActionResult OrderInMES()
        {
            var filter = new OrderInMESFilterModel
            {
                Plant = "7501",
                Shop = "Engine",
                Model = "ALL",
                Shift = "ALL",
                OrderState = "ALL",
                QualityState = "ALL",
                FromDate = DateTime.Today,
                FromHour = "12",
                FromMin = "00",
                FromAmPm = "AM",
                ToDate = DateTime.Today,
                ToHour = "11",
                ToMin = "59",
                ToAmPm = "PM"
            };

            var viewModel = _orderInMESRepository.GetOrderInMESReport(filter);
            return View(viewModel);
        }

        [HttpPost]
        public IActionResult OrderInMES(OrderInMESFilterModel filter)
        {
            var viewModel = _orderInMESRepository.GetOrderInMESReport(filter);
            return View(viewModel);
        }

        [HttpPost]
        public IActionResult GetOrderInMESDataJson([FromBody] OrderInMESFilterModel filter)
        {
            try
            {
                var viewModel = _orderInMESRepository.GetOrderInMESReport(filter);
                return Json(new { success = true, data = viewModel });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        #endregion

        #region TCF NFT Report Actions

        [HttpGet]
        public IActionResult TcfNft()
        {
            TcfNftFilterModel filter = new TcfNftFilterModel
            {
                Model = "ALL",
                Shift = "ALL",
                FromDate = DateTime.Today,
                FromHour = "12",
                FromMin = "00",
                FromAmPm = "AM",
                ToDate = DateTime.Today,
                ToHour = "11",
                ToMin = "59",
                ToAmPm = "PM"
            };

            TcfNftViewModel viewModel = _tcfNftRepository.GetTcfNftReport(filter);

            return View(viewModel);
        }

        [HttpPost]
        public IActionResult TcfNft(TcfNftFilterModel filter)
        {
            TcfNftViewModel viewModel = _tcfNftRepository.GetTcfNftReport(filter);
            return View(viewModel);
        }

        [HttpPost]
        public IActionResult ExportTcfNftExcel(TcfNftFilterModel filter)
        {
            try
            {
                TcfNftViewModel viewModel = _tcfNftRepository.GetTcfNftReport(filter);

                var builder = new StringBuilder();
                builder.AppendLine("Sr.No,Date,Time,VIN,Item,Defect,Booked Against,QA Status,Reported By");

                if (viewModel?.Details != null && viewModel.Details.Count > 0)
                {
                    foreach (var item in viewModel.Details)
                    {
                        string srNo = EscapeCsvField(item.SrNo.ToString());
                        string date = EscapeCsvField(item.Date);
                        string time = EscapeCsvField(item.Time);
                        string vin = EscapeCsvField(item.Vin);
                        string itemVal = EscapeCsvField(item.Item);
                        string defect = EscapeCsvField(item.Defect);
                        string bookedAgainst = EscapeCsvField(item.BookedAgainst);
                        string qaStatus = EscapeCsvField(item.QaStatus);
                        string reportedBy = EscapeCsvField(item.ReportedBy);

                        builder.AppendLine($"{srNo},{date},{time},{vin},{itemVal},{defect},{bookedAgainst},{qaStatus},{reportedBy}");
                    }
                }

                byte[] buffer = Encoding.UTF8.GetPreamble()
                    .Concat(Encoding.UTF8.GetBytes(builder.ToString()))
                    .ToArray();

                string fileName = $"TCF_NFT_Report_{DateTime.Now:yyyyMMdd_HHmmss}.csv";

                Response.Headers["Access-Control-Expose-Headers"] = "Content-Disposition";

                return File(buffer, "text/csv", fileName);
            }
            catch (Exception ex)
            {
                return BadRequest("Error generating report export: " + ex.Message);
            }
        }

        private static string EscapeCsvField(string? field)
        {
            if (string.IsNullOrEmpty(field)) return "\"\"";
            string value = field.Replace("\"", "\"\"");
            return $"\"{value}\"";
        }

        #endregion

        #region BIW Vin Generation Report Actions

        [HttpGet]
        public IActionResult BiwVinGeneration()
        {
            BiwVinGenerationFilterModel filter = new BiwVinGenerationFilterModel
            {
                VinNumber = string.Empty,
                Model = "ALL",
                Shift = "ALL",
                FromDate = DateTime.Today,
                FromHour = "12",
                FromMin = "00",
                FromAmPm = "AM",
                ToDate = DateTime.Today,
                ToHour = "11",
                ToMin = "59",
                ToAmPm = "PM"
            };

            BiwVinGenerationViewModel viewModel = _biwVinGenerationRepository.GetBiwVinGenerationReport(filter);

            return View(viewModel);
        }

        [HttpPost]
        public IActionResult BiwVinGeneration(BiwVinGenerationFilterModel filter)
        {
            BiwVinGenerationViewModel viewModel = _biwVinGenerationRepository.GetBiwVinGenerationReport(filter);
            return View(viewModel);
        }

        [HttpPost]
        public IActionResult GetBiwVinGenerationDataJson([FromBody] BiwVinGenerationFilterModel filter)
        {
            try
            {
                var viewModel = _biwVinGenerationRepository.GetBiwVinGenerationReport(filter);
                return Json(new { success = true, data = viewModel });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        #endregion
#region TCF Vin Generation Report Actions

[HttpGet]
public IActionResult TcfVinGeneration()
{
    var filter = new TcfVinGenerationFilterModel
    {
        FromDate = DateTime.Today,
        ToDate = DateTime.Today
    };

    var viewModel =
        _tcfVinRepository.GetTcfVinGenerationReport(filter);

    return View(viewModel);
}

[HttpPost]
public IActionResult TcfVinGeneration(
    TcfVinGenerationFilterModel filter)
{
    var viewModel =
        _tcfVinRepository.GetTcfVinGenerationReport(filter);

    return View(viewModel);
}

[HttpPost]
public IActionResult GetTcfVinGenerationDataJson(
    [FromBody] TcfVinGenerationFilterModel filter)
{
    try
    {
        var viewModel =
            _tcfVinRepository.GetTcfVinGenerationReport(filter);

        return Json(new
        {
            success = true,
            data = viewModel
        });
    }
    catch (Exception ex)
    {
        return Json(new
        {
            success = false,
            message = ex.Message
        });
    }
}

#endregion

#region TCF OEM Data Report Actions

[HttpGet]
public IActionResult TcfOemDataReport()
{
    var filter = new TcfOemDataFilterModel
    {
        Shift = "ALL",

        FromDate = DateTime.Today,
        FromHour = "06",
        FromMin = "30",
        FromAmPm = "AM",

        ToDate = DateTime.Today.AddDays(1),
        ToHour = "06",
        ToMin = "30",
        ToAmPm = "AM"
    };

    TcfOemDataViewModel viewModel =
        _tcfOemDataReportRepository.GetTcfOemDataReport(filter);

    return View(viewModel);
}

[HttpPost]
[ValidateAntiForgeryToken]
public IActionResult TcfOemDataReport(
    TcfOemDataFilterModel filter)
{
    TcfOemDataViewModel viewModel =
        _tcfOemDataReportRepository.GetTcfOemDataReport(filter);

    return View(viewModel);
}

[HttpPost]
[ValidateAntiForgeryToken]
public IActionResult GetTcfOemDataReportJson(
    [FromBody] TcfOemDataFilterModel? filter)
{
    try
    {
        filter ??= new TcfOemDataFilterModel
        {
            Shift = "ALL",

            FromDate = DateTime.Today,
            FromHour = "06",
            FromMin = "30",
            FromAmPm = "AM",

            ToDate = DateTime.Today.AddDays(1),
            ToHour = "06",
            ToMin = "30",
            ToAmPm = "AM"
        };

        TcfOemDataViewModel viewModel =
            _tcfOemDataReportRepository.GetTcfOemDataReport(filter);

        if (!string.IsNullOrWhiteSpace(viewModel.ErrorMessage))
        {
            return Json(new
            {
                success = false,
                message = viewModel.ErrorMessage
            });
        }

        return Json(new
        {
            success = true,
            data = viewModel
        });
    }
    catch (Exception ex)
    {
        return Json(new
        {
            success = false,
            message = ex.Message
        });
    }
}

#endregion

        #region JIS Report Actions

        [HttpGet]
        public IActionResult JisReport()
        {
            var viewModel = _jisReportRepository.GetJisReport();
            return View(viewModel);
        }

        [HttpPost]
        public IActionResult GetJisReportDataJson()
        {
            try
            {
                var viewModel = _jisReportRepository.GetJisReport();
                return Json(new { success = true, data = viewModel });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        #endregion

        #region QG Wise Tracking Report Actions

        [HttpGet]
        public IActionResult QGWiseTracking()
        {
            var viewModel = new QGWiseTrackingReportViewModel();
            return View(viewModel);
        }

        [HttpPost]
        public IActionResult QGWiseTracking(string vinNumber)
        {
            var viewModel = _qgWiseTrackingReportRepository.GetReport(vinNumber);
            return View(viewModel);
        }

        #endregion

        #region ILCR Report Actions

        [HttpGet]
        public IActionResult IlcrReport()
        {
            var filter = new IlcrReportFilterModel();
            var viewModel = _ilcrReportRepository.GetIlcrReport(filter);
            return View(viewModel);
        }

        [HttpPost]
        public IActionResult IlcrReport(IlcrReportFilterModel filter)
        {
            var viewModel = _ilcrReportRepository.GetIlcrReport(filter);
            return View(viewModel);
        }

        [HttpPost]
        public IActionResult GetIlcrReportDataJson([FromBody] IlcrReportFilterModel? filter)
        {
            try
            {
                filter ??= new IlcrReportFilterModel();
                var viewModel = _ilcrReportRepository.GetIlcrReport(filter);
                return Json(new { success = true, data = viewModel });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        #endregion

        #region Live WIP Report Test Actions

        [HttpGet]
        public IActionResult LiveWIPReportTest()
        {
            var viewModel = _liveWIPReportTestRepository.GetLiveWIPReportData();
            return View(viewModel);
        }

        [HttpPost]
        public IActionResult GetLiveWIPReportDataJson()
        {
            try
            {
                var viewModel = _liveWIPReportTestRepository.GetLiveWIPReportData();
                return Json(new { success = true, data = viewModel });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        #endregion

        #region Live WIP Report Actions

        [HttpGet]
        public IActionResult LiveWIPReport()
        {
            var viewModel = _liveWIPReportRepository.GetLiveWIPReportData();
            return View(viewModel);
        }

        [HttpPost]
        public IActionResult GetLiveWIPReportDataJsonLive()
        {
            try
            {
                var viewModel = _liveWIPReportRepository.GetLiveWIPReportData();
                return Json(new { success = true, data = viewModel });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        #endregion

        #region Daily Order Summary Report Actions

        [HttpGet]
        public IActionResult DailyOrderSummary()
        {
            var filter = new DailyOrderSummaryFilterModel
            {
                Plant = "7501",
                Shop = "TCF",
                Model = "ALL",
                Shift = "ALL",
                FromDate = DateTime.Today,
                ToDate = DateTime.Today
            };

            var viewModel = _dailyOrderSummaryRepository.GetDailyOrderSummaryReport(filter);
            return View(viewModel);
        }

        [HttpPost]
        public IActionResult DailyOrderSummary(DailyOrderSummaryFilterModel filter)
        {
            var viewModel = _dailyOrderSummaryRepository.GetDailyOrderSummaryReport(filter);
            return View(viewModel);
        }

        [HttpPost]
        public IActionResult GetDailyOrderSummaryDataJson([FromBody] DailyOrderSummaryFilterModel filter)
        {
            try
            {
                var viewModel = _dailyOrderSummaryRepository.GetDailyOrderSummaryReport(filter);
                return Json(new { success = true, data = viewModel });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        #endregion

        #region Daily Order Summary Partwise Report Actions

        [HttpGet]
        public IActionResult DailyOrderSummaryPartwise()
        {
            var filter = new DailyOrderSummaryPartwiseFilterModel
            {
                Plant = "7501",
                Shop = "TCF",
                Model = "ALL",
                Shift = "ALL",
                FromDate = DateTime.Today,
                ToDate = DateTime.Today
            };

            var viewModel = _dailyOrderSummaryPartwiseRepository.GetDailyOrderSummaryPartwiseReport(filter);
            return View(viewModel);
        }

        [HttpPost]
        public IActionResult DailyOrderSummaryPartwise(DailyOrderSummaryPartwiseFilterModel filter)
        {
            var viewModel = _dailyOrderSummaryPartwiseRepository.GetDailyOrderSummaryPartwiseReport(filter);
            return View(viewModel);
        }

        [HttpPost]
        public IActionResult GetDailyOrderSummaryPartwiseDataJson([FromBody] DailyOrderSummaryPartwiseFilterModel filter)
        {
            try
            {
                var viewModel = _dailyOrderSummaryPartwiseRepository.GetDailyOrderSummaryPartwiseReport(filter);
                return Json(new { success = true, data = viewModel });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        #endregion

        #region TCF EOL DRR Report Actions

        [HttpGet]
        [Route("Production/TcfEolDrrReport")]
        public IActionResult TcfEolDrrReport()
        {
            var filter = new TcfEolDrrFilterModel
            {
                Station = "CANOPY",
                Model = "ALL",
                Shift = "ALL",
                FromDate = DateTime.Today,
                ToDate = DateTime.Today
            };

            var viewModel = _tcfEolDrrRepository.GetTcfEolDrrReport(filter);
            return View(viewModel);
        }

        [HttpPost]
        [Route("Production/TcfEolDrrReport")]
        public IActionResult TcfEolDrrReport(TcfEolDrrFilterModel filter)
        {
            var viewModel = _tcfEolDrrRepository.GetTcfEolDrrReport(filter);
            return View(viewModel);
        }

        [HttpPost]
        public IActionResult GetTcfEolDrrDataJson([FromBody] TcfEolDrrFilterModel filter)
        {
            try
            {
                var viewModel = _tcfEolDrrRepository.GetTcfEolDrrReport(filter);
                return Json(new { success = true, data = viewModel });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        #endregion
    }
}