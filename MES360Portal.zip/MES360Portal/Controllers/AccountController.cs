using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using BCrypt.Net;
using MES360Portal.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace MES360Portal.Controllers
{
    public class AccountController : Controller
    {
        private const string FullNameClaimType = "FullName";

        private readonly string _connectionString;

        public AccountController(IConfiguration configuration)
        {
            _connectionString =
                configuration.GetConnectionString("PDSDB")
                ?? throw new InvalidOperationException(
                    "PDSDB connection string is missing.");
        }

        #region Login and Logout

        // GET: /Account/Login
        [AllowAnonymous]
        [HttpGet]
        public IActionResult Login(string? returnUrl = null)
        {
            if (User.Identity?.IsAuthenticated == true)
            {
                return RedirectToLocal(returnUrl);
            }

            ViewData["ReturnUrl"] = returnUrl;

            return View();
        }

        // POST: /Account/Login
        [AllowAnonymous]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(
            LoginViewModel model,
            string? returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            string submittedUsername =
                model.Username?.Trim() ?? string.Empty;

            if (string.IsNullOrWhiteSpace(submittedUsername))
            {
                ModelState.AddModelError(
                    nameof(model.Username),
                    "Username is required.");

                return View(model);
            }

            const string query = @"
SELECT TOP (1)
    UserId,
    Username,
    PasswordHash,
    FullName,
    IsAdmin
FROM dbo.Users
WHERE Username = @Username;";

            await using SqlConnection connection =
                new SqlConnection(_connectionString);

            await using SqlCommand command =
                new SqlCommand(query, connection);

            command.Parameters.Add(
                "@Username",
                SqlDbType.NVarChar,
                256).Value = submittedUsername;

            await connection.OpenAsync();

            await using SqlDataReader reader =
                await command.ExecuteReaderAsync(
                    CommandBehavior.SingleRow);

            if (!await reader.ReadAsync())
            {
                AddInvalidLoginError();
                return View(model);
            }

            string storedPasswordHash =
                GetNullableString(
                    reader,
                    "PasswordHash");

            if (string.IsNullOrWhiteSpace(storedPasswordHash))
            {
                AddInvalidLoginError();
                return View(model);
            }

            bool passwordVerified;

            try
            {
                passwordVerified =
                    BCrypt.Net.BCrypt.Verify(
                        model.Password,
                        storedPasswordHash);
            }
            catch (SaltParseException)
            {
                passwordVerified = false;
            }

            if (!passwordVerified)
            {
                AddInvalidLoginError();
                return View(model);
            }

            int userId =
                reader.GetInt32(
                    reader.GetOrdinal("UserId"));

            string username =
                GetNullableString(
                    reader,
                    "Username").Trim();

            string storedFullName =
                GetNullableString(
                    reader,
                    "FullName").Trim();

            bool isAdmin =
                reader.GetBoolean(
                    reader.GetOrdinal("IsAdmin"));

            string fullName =
                string.IsNullOrWhiteSpace(storedFullName)
                    ? username
                    : storedFullName;

            var claims = new List<Claim>
            {
                new Claim(
                    ClaimTypes.NameIdentifier,
                    userId.ToString()),

                new Claim(
                    ClaimTypes.Name,
                    username),

                new Claim(
                    FullNameClaimType,
                    fullName),

                new Claim(
                    ClaimTypes.Role,
                    isAdmin ? "Admin" : "User")
            };

            var claimsIdentity =
                new ClaimsIdentity(
                    claims,
                    CookieAuthenticationDefaults
                        .AuthenticationScheme);

            var authenticationProperties =
                new AuthenticationProperties
                {
                    IsPersistent = true,
                    AllowRefresh = true,
                    ExpiresUtc =
                        DateTimeOffset.UtcNow
                            .AddHours(8)
                };

            await HttpContext.SignInAsync(
                CookieAuthenticationDefaults
                    .AuthenticationScheme,
                new ClaimsPrincipal(claimsIdentity),
                authenticationProperties);

            return RedirectToLocal(returnUrl);
        }

        // POST: /Account/Logout
        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(
                CookieAuthenticationDefaults
                    .AuthenticationScheme);

            return RedirectToAction(
                nameof(Login),
                "Account");
        }

        #endregion

        #region Admin Panel

        // GET: /Account/AdminPanel
        [Authorize(Roles = "Admin")]
        [HttpGet]
        public async Task<IActionResult> AdminPanel()
        {
            var users =
                new List<AdminUserViewModel>();

            List<string> allSystemTabs =
                GetSystemTabs();

            await using SqlConnection connection =
                new SqlConnection(_connectionString);

            await connection.OpenAsync();

            const string userQuery = @"
SELECT
    UserId,
    Username,
    FullName,
    IsAdmin
FROM dbo.Users
ORDER BY UserId DESC;";

            await using (
                SqlCommand command =
                    new SqlCommand(
                        userQuery,
                        connection))
            {
                await using SqlDataReader reader =
                    await command.ExecuteReaderAsync();

                int userIdOrdinal =
                    reader.GetOrdinal("UserId");

                int usernameOrdinal =
                    reader.GetOrdinal("Username");

                int fullNameOrdinal =
                    reader.GetOrdinal("FullName");

                int isAdminOrdinal =
                    reader.GetOrdinal("IsAdmin");

                while (await reader.ReadAsync())
                {
                    string username =
                        reader.IsDBNull(usernameOrdinal)
                            ? string.Empty
                            : reader.GetString(
                                usernameOrdinal);

                    string fullName =
                        reader.IsDBNull(fullNameOrdinal)
                            ? username
                            : reader.GetString(
                                fullNameOrdinal);

                    if (string.IsNullOrWhiteSpace(fullName))
                    {
                        fullName = username;
                    }

                    users.Add(
                        new AdminUserViewModel
                        {
                            UserId =
                                reader.GetInt32(
                                    userIdOrdinal),

                            Username =
                                username.Trim(),

                            FullName =
                                fullName.Trim(),

                            IsAdmin =
                                reader.GetBoolean(
                                    isAdminOrdinal)
                        });
                }
            }

            foreach (AdminUserViewModel user in users)
            {
                var savedPermissions =
                    new Dictionary<string, bool>(
                        StringComparer.OrdinalIgnoreCase);

                const string tabQuery = @"
SELECT
    TabName,
    CanAccess
FROM dbo.UserTabAccess
WHERE UserId = @UserId;";

                await using SqlCommand command =
                    new SqlCommand(
                        tabQuery,
                        connection);

                command.Parameters.Add(
                    "@UserId",
                    SqlDbType.Int).Value =
                        user.UserId;

                await using SqlDataReader reader =
                    await command.ExecuteReaderAsync();

                int tabNameOrdinal =
                    reader.GetOrdinal("TabName");

                int canAccessOrdinal =
                    reader.GetOrdinal("CanAccess");

                while (await reader.ReadAsync())
                {
                    string tabName =
                        reader.IsDBNull(tabNameOrdinal)
                            ? string.Empty
                            : reader.GetString(
                                tabNameOrdinal);

                    if (string.IsNullOrWhiteSpace(tabName))
                    {
                        continue;
                    }

                    bool canAccess =
                        !reader.IsDBNull(canAccessOrdinal)
                        &&
                        reader.GetBoolean(
                            canAccessOrdinal);

                    savedPermissions[tabName] =
                        canAccess;
                }

                user.TabPermissions =
                    allSystemTabs
                        .Select(
                            tabName =>
                                new TabPermissionModel
                                {
                                    TabName =
                                        tabName,

                                    CanAccess =
                                        user.IsAdmin
                                        ||
                                        (
                                            savedPermissions
                                                .TryGetValue(
                                                    tabName,
                                                    out bool canAccess)
                                            &&
                                            canAccess
                                        )
                                })
                        .ToList();
            }

            return View(users);
        }

        #endregion

        #region User Permission Management

        // POST: /Account/UpdateUserTabAccess
        [Authorize(Roles = "Admin")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult>
            UpdateUserTabAccess(
                int userId,
                Dictionary<string, bool>? tabAccess)
        {
            if (userId <= 0)
            {
                TempData["ErrorMessage"] =
                    "Invalid user selected.";

                return RedirectToAction(
                    nameof(AdminPanel));
            }

            await using SqlConnection connection =
                new SqlConnection(_connectionString);

            await connection.OpenAsync();

            bool userExists =
                await UserExistsAsync(
                    connection,
                    userId);

            if (!userExists)
            {
                TempData["ErrorMessage"] =
                    "The selected user does not exist.";

                return RedirectToAction(
                    nameof(AdminPanel));
            }

            await using SqlTransaction transaction =
                (SqlTransaction)
                await connection.BeginTransactionAsync();

            try
            {
                const string upsertQuery = @"
IF EXISTS
(
    SELECT 1
    FROM dbo.UserTabAccess
    WHERE UserId = @UserId
      AND TabName = @TabName
)
BEGIN
    UPDATE dbo.UserTabAccess
    SET CanAccess = @CanAccess
    WHERE UserId = @UserId
      AND TabName = @TabName;
END
ELSE
BEGIN
    INSERT INTO dbo.UserTabAccess
    (
        UserId,
        TabName,
        CanAccess
    )
    VALUES
    (
        @UserId,
        @TabName,
        @CanAccess
    );
END;";

                foreach (string tabName
                    in GetSystemTabs())
                {
                    bool canAccess =
                        tabAccess != null
                        &&
                        tabAccess.TryGetValue(
                            tabName,
                            out bool selected)
                        &&
                        selected;

                    await using SqlCommand command =
                        new SqlCommand(
                            upsertQuery,
                            connection,
                            transaction);

                    command.Parameters.Add(
                        "@UserId",
                        SqlDbType.Int).Value =
                            userId;

                    command.Parameters.Add(
                        "@TabName",
                        SqlDbType.NVarChar,
                        150).Value =
                            tabName;

                    command.Parameters.Add(
                        "@CanAccess",
                        SqlDbType.Bit).Value =
                            canAccess;

                    await command.ExecuteNonQueryAsync();
                }

                await transaction.CommitAsync();

                TempData["SuccessMessage"] =
                    "User tab access updated successfully.";
            }
            catch
            {
                await transaction.RollbackAsync();

                TempData["ErrorMessage"] =
                    "Unable to update user tab access. " +
                    "No permission changes were saved.";
            }

            return RedirectToAction(
                nameof(AdminPanel));
        }

        #endregion

        #region User Creation

        // POST: /Account/CreateUser
        [Authorize(Roles = "Admin")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateUser(
            string newUsername,
            string newPassword,
            string newFullName,
            bool isAdmin)
        {
            string username =
                newUsername?.Trim()
                ?? string.Empty;

            string fullName =
                newFullName?.Trim()
                ?? string.Empty;

            if (string.IsNullOrWhiteSpace(username))
            {
                TempData["ErrorMessage"] =
                    "Email address is required.";

                return RedirectToAction(
                    nameof(AdminPanel));
            }

            if (string.IsNullOrWhiteSpace(newPassword))
            {
                TempData["ErrorMessage"] =
                    "Password is required.";

                return RedirectToAction(
                    nameof(AdminPanel));
            }

            if (newPassword.Length < 8)
            {
                TempData["ErrorMessage"] =
                    "Password must contain at least 8 characters.";

                return RedirectToAction(
                    nameof(AdminPanel));
            }

            if (string.IsNullOrWhiteSpace(fullName))
            {
                fullName = username;
            }

            await using SqlConnection connection =
                new SqlConnection(_connectionString);

            await connection.OpenAsync();

            bool usernameExists =
                await UsernameExistsAsync(
                    connection,
                    username);

            if (usernameExists)
            {
                TempData["ErrorMessage"] =
                    $"A user with email '{username}' " +
                    "already exists.";

                return RedirectToAction(
                    nameof(AdminPanel));
            }

            string passwordHash =
                BCrypt.Net.BCrypt.HashPassword(
                    newPassword);

            const string insertQuery = @"
INSERT INTO dbo.Users
(
    Username,
    PasswordHash,
    FullName,
    IsAdmin
)
VALUES
(
    @Username,
    @PasswordHash,
    @FullName,
    @IsAdmin
);";

            try
            {
                await using SqlCommand command =
                    new SqlCommand(
                        insertQuery,
                        connection);

                command.Parameters.Add(
                    "@Username",
                    SqlDbType.NVarChar,
                    256).Value =
                        username;

                command.Parameters.Add(
                    "@PasswordHash",
                    SqlDbType.NVarChar,
                    500).Value =
                        passwordHash;

                command.Parameters.Add(
                    "@FullName",
                    SqlDbType.NVarChar,
                    200).Value =
                        fullName;

                command.Parameters.Add(
                    "@IsAdmin",
                    SqlDbType.Bit).Value =
                        isAdmin;

                await command.ExecuteNonQueryAsync();

                TempData["SuccessMessage"] =
                    $"User '{username}' created successfully.";
            }
            catch (SqlException exception)
                when (
                    exception.Number == 2601
                    ||
                    exception.Number == 2627)
            {
                TempData["ErrorMessage"] =
                    $"A user with email '{username}' " +
                    "already exists.";
            }

            return RedirectToAction(
                nameof(AdminPanel));
        }

        #endregion

        #region Password Reset

        // POST: /Account/ResetPassword
        [Authorize(Roles = "Admin")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ResetPassword(
            int targetUserId,
            string newPassword)
        {
            if (targetUserId <= 0)
            {
                TempData["ErrorMessage"] =
                    "Invalid user selected.";

                return RedirectToAction(
                    nameof(AdminPanel));
            }

            if (string.IsNullOrWhiteSpace(newPassword))
            {
                TempData["ErrorMessage"] =
                    "New password cannot be empty.";

                return RedirectToAction(
                    nameof(AdminPanel));
            }

            if (newPassword.Length < 8)
            {
                TempData["ErrorMessage"] =
                    "New password must contain at least " +
                    "8 characters.";

                return RedirectToAction(
                    nameof(AdminPanel));
            }

            string passwordHash =
                BCrypt.Net.BCrypt.HashPassword(
                    newPassword);

            const string updateQuery = @"
UPDATE dbo.Users
SET PasswordHash = @PasswordHash
WHERE UserId = @UserId;";

            await using SqlConnection connection =
                new SqlConnection(_connectionString);

            await using SqlCommand command =
                new SqlCommand(
                    updateQuery,
                    connection);

            command.Parameters.Add(
                "@PasswordHash",
                SqlDbType.NVarChar,
                500).Value =
                    passwordHash;

            command.Parameters.Add(
                "@UserId",
                SqlDbType.Int).Value =
                    targetUserId;

            await connection.OpenAsync();

            int affectedRows =
                await command.ExecuteNonQueryAsync();

            if (affectedRows == 0)
            {
                TempData["ErrorMessage"] =
                    "The selected user does not exist.";
            }
            else
            {
                TempData["SuccessMessage"] =
                    "Password updated successfully.";
            }

            return RedirectToAction(
                nameof(AdminPanel));
        }

        #endregion

        #region User Removal

        // POST: /Account/DeleteUserByEmail
        [Authorize(Roles = "Admin")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteUserByEmail(
            string userEmail)
        {
            string normalizedEmail =
                userEmail?.Trim()
                ?? string.Empty;

            if (string.IsNullOrWhiteSpace(normalizedEmail))
            {
                TempData["ErrorMessage"] =
                    "User email address is required.";

                return RedirectToAction(
                    nameof(AdminPanel));
            }

            string currentUserEmail =
                User.Identity?.Name?.Trim()
                ?? string.Empty;

            if (string.Equals(
                currentUserEmail,
                normalizedEmail,
                StringComparison.OrdinalIgnoreCase))
            {
                TempData["ErrorMessage"] =
                    "You cannot remove your own signed-in account.";

                return RedirectToAction(
                    nameof(AdminPanel));
            }

            await using SqlConnection connection =
                new SqlConnection(_connectionString);

            await connection.OpenAsync();

            await using SqlTransaction transaction =
                (SqlTransaction)
                await connection.BeginTransactionAsync();

            try
            {
                int targetUserId;
                bool targetIsAdmin;

                const string findUserQuery = @"
SELECT
    UserId,
    IsAdmin
FROM dbo.Users
WHERE Username = @UserEmail;";

                var matchingUsers =
                    new List<(int UserId, bool IsAdmin)>();

                await using (
                    SqlCommand findUserCommand =
                        new SqlCommand(
                            findUserQuery,
                            connection,
                            transaction))
                {
                    findUserCommand.Parameters.Add(
                        "@UserEmail",
                        SqlDbType.NVarChar,
                        256).Value =
                            normalizedEmail;

                    await using SqlDataReader reader =
                        await findUserCommand
                            .ExecuteReaderAsync();

                    int userIdOrdinal =
                        reader.GetOrdinal("UserId");

                    int isAdminOrdinal =
                        reader.GetOrdinal("IsAdmin");

                    while (await reader.ReadAsync())
                    {
                        matchingUsers.Add(
                            (
                                reader.GetInt32(
                                    userIdOrdinal),

                                reader.GetBoolean(
                                    isAdminOrdinal)
                            ));
                    }
                }

                if (matchingUsers.Count == 0)
                {
                    await transaction.RollbackAsync();

                    TempData["ErrorMessage"] =
                        $"No user was found with email " +
                        $"'{normalizedEmail}'.";

                    return RedirectToAction(
                        nameof(AdminPanel));
                }

                if (matchingUsers.Count > 1)
                {
                    await transaction.RollbackAsync();

                    TempData["ErrorMessage"] =
                        $"Multiple accounts use email " +
                        $"'{normalizedEmail}'. Resolve the " +
                        "duplicate records before removing " +
                        "this user.";

                    return RedirectToAction(
                        nameof(AdminPanel));
                }

                targetUserId =
                    matchingUsers[0].UserId;

                targetIsAdmin =
                    matchingUsers[0].IsAdmin;

                if (targetIsAdmin)
                {
                    const string adminCountQuery = @"
SELECT COUNT(1)
FROM dbo.Users
WHERE IsAdmin = 1;";

                    int adminCount;

                    await using SqlCommand adminCountCommand =
                        new SqlCommand(
                            adminCountQuery,
                            connection,
                            transaction);

                    object? result =
                        await adminCountCommand
                            .ExecuteScalarAsync();

                    adminCount =
                        Convert.ToInt32(result);

                    if (adminCount <= 1)
                    {
                        await transaction.RollbackAsync();

                        TempData["ErrorMessage"] =
                            "The final administrator account " +
                            "cannot be removed.";

                        return RedirectToAction(
                            nameof(AdminPanel));
                    }
                }

                const string deletePermissionsQuery = @"
DELETE FROM dbo.UserTabAccess
WHERE UserId = @UserId;";

                await using (
                    SqlCommand deletePermissionsCommand =
                        new SqlCommand(
                            deletePermissionsQuery,
                            connection,
                            transaction))
                {
                    deletePermissionsCommand.Parameters.Add(
                        "@UserId",
                        SqlDbType.Int).Value =
                            targetUserId;

                    await deletePermissionsCommand
                        .ExecuteNonQueryAsync();
                }

                const string deleteUserQuery = @"
DELETE FROM dbo.Users
WHERE UserId = @UserId
  AND Username = @UserEmail;";

                int deletedUserCount;

                await using (
                    SqlCommand deleteUserCommand =
                        new SqlCommand(
                            deleteUserQuery,
                            connection,
                            transaction))
                {
                    deleteUserCommand.Parameters.Add(
                        "@UserId",
                        SqlDbType.Int).Value =
                            targetUserId;

                    deleteUserCommand.Parameters.Add(
                        "@UserEmail",
                        SqlDbType.NVarChar,
                        256).Value =
                            normalizedEmail;

                    deletedUserCount =
                        await deleteUserCommand
                            .ExecuteNonQueryAsync();
                }

                if (deletedUserCount != 1)
                {
                    throw new InvalidOperationException(
                        "The account changed during the " +
                        "operation and could not be removed.");
                }

                await transaction.CommitAsync();

                TempData["SuccessMessage"] =
                    $"User '{normalizedEmail}' and all " +
                    "assigned report permissions were " +
                    "removed successfully.";
            }
            catch (Exception ex)
            {
                if (transaction.Connection != null)
                {
                    try
                    {
                        await transaction.RollbackAsync();
                    }
                    catch
                    {
                        // Preserve the original exception.
                    }
                }

                TempData["ErrorMessage"] =
                    "Unable to remove the user. " +
                    ex.Message;
            }

            return RedirectToAction(
                nameof(AdminPanel));
        }

        #endregion

        #region Private Helpers

        private void AddInvalidLoginError()
        {
            ModelState.AddModelError(
                string.Empty,
                "Invalid username or password.");
        }

        private IActionResult RedirectToLocal(
            string? returnUrl)
        {
            if (!string.IsNullOrWhiteSpace(returnUrl)
                &&
                Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }

            return RedirectToAction(
                "Index",
                "Home");
        }

        private static string GetNullableString(
            SqlDataReader reader,
            string columnName)
        {
            int ordinal =
                reader.GetOrdinal(columnName);

            return reader.IsDBNull(ordinal)
                ? string.Empty
                : reader.GetString(ordinal);
        }

        private static async Task<bool>
            UserExistsAsync(
                SqlConnection connection,
                int userId)
        {
            const string query = @"
SELECT COUNT(1)
FROM dbo.Users
WHERE UserId = @UserId;";

            await using SqlCommand command =
                new SqlCommand(
                    query,
                    connection);

            command.Parameters.Add(
                "@UserId",
                SqlDbType.Int).Value =
                    userId;

            object? result =
                await command.ExecuteScalarAsync();

            return Convert.ToInt32(result) > 0;
        }

        private static async Task<bool>
            UsernameExistsAsync(
                SqlConnection connection,
                string username)
        {
            const string query = @"
SELECT COUNT(1)
FROM dbo.Users
WHERE Username = @Username;";

            await using SqlCommand command =
                new SqlCommand(
                    query,
                    connection);

            command.Parameters.Add(
                "@Username",
                SqlDbType.NVarChar,
                256).Value =
                    username;

            object? result =
                await command.ExecuteScalarAsync();

            return Convert.ToInt32(result) > 0;
        }

        private static List<string> GetSystemTabs()
        {
            return new List<string>
            {
                "Dashboard",
                "Daily Production Report",
                "QGWiseTracking Report",
                "TCF NFT Report",
                "TCF VIN Generation",
                "BINEX Tool Report",
                "BIW VIN Generation",
                "Live WIP Report",
                "Live WIP Report Test",
                "JIS Report",
                "Daily Order Summary",
                "Order Summary Partwise",
                "TCF EOL DRR Report",
                "Order In MES",
                "ILCR Report",
                "Quality Reports",
                "Test Data Reports",
                "Help"
            };
        }

        #endregion
    }
}