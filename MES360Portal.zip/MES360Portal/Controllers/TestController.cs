using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;

namespace MES360Portal.Controllers
{
    public class TestController : Controller
    {
        private readonly IConfiguration _configuration;

        public TestController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public IActionResult DbConnection()
        {
            try
            {
                string connectionString = _configuration.GetConnectionString("MESDB") ?? "";

                using SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();

                return Content("Database Connected Successfully");
            }
            catch (Exception ex)
            {
                return Content("Database Connection Failed: " + ex.Message);
            }
        }
    }
}