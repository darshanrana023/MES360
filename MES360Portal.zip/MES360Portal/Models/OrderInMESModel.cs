using System;
using System.Collections.Generic;

namespace MES360Portal.Models
{
    public class OrderInMESFilterModel
    {
        public string Plant { get; set; } = "7501";
        public string Shop { get; set; } = "Engine";
        public string Model { get; set; } = "ALL";
        public string Shift { get; set; } = "ALL";
        public string OrderState { get; set; } = "ALL";
        public string QualityState { get; set; } = "ALL";
        public DateTime? FromDate { get; set; }
        public string FromHour { get; set; } = "12";
        public string FromMin { get; set; } = "00";
        public string FromAmPm { get; set; } = "AM";
        public DateTime? ToDate { get; set; }
        public string ToHour { get; set; } = "11";
        public string ToMin { get; set; } = "59";
        public string ToAmPm { get; set; } = "PM";
    }

    public class OrderInMESDetailModel
    {
        public int SrNo { get; set; }
        public string OrderNumber { get; set; } = string.Empty;
        public string PartNumber { get; set; } = string.Empty;
        public string SerialNumber { get; set; } = string.Empty;
        public string Model { get; set; } = string.Empty;
        public string Emission { get; set; } = string.Empty;
        public string Color { get; set; } = string.Empty;
        public string StartTime { get; set; } = string.Empty;
        public string BookingTime { get; set; } = string.Empty;
        public string ProdQAOKTime { get; set; } = string.Empty;
        public string QAOKTime { get; set; } = string.Empty;
        public string ClosedTime { get; set; } = string.Empty;
        public string OrderState { get; set; } = string.Empty;
    }

    public class OrderInMESViewModel
    {
        public OrderInMESFilterModel Filter { get; set; } = new OrderInMESFilterModel();
        public List<OrderInMESDetailModel> Details { get; set; } = new List<OrderInMESDetailModel>();
        public string ErrorMessage { get; set; } = string.Empty;
    }
}