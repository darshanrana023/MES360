using System;
using System.Collections.Generic;
using System.Globalization;

namespace MES360Portal.Models
{
    public class TcfOemDataFilterModel
    {
        public string Shift { get; set; } = "ALL";

        public DateTime? FromDate { get; set; } = DateTime.Today;

        public string FromHour { get; set; } = "06";

        public string FromMin { get; set; } = "30";

        public string FromAmPm { get; set; } = "AM";

        public DateTime? ToDate { get; set; } = DateTime.Today.AddDays(1);

        public string ToHour { get; set; } = "06";

        public string ToMin { get; set; } = "30";

        public string ToAmPm { get; set; } = "AM";
    }

    public class TcfOemDataDetailModel
    {
        public int SrNo { get; set; }

        public long RowId { get; set; }

        public DateTime? RowInsertTime { get; set; }

        public string VinNumber { get; set; } = string.Empty;

        public int? Pin1Result { get; set; }

        public int? Pin2Result { get; set; }

        public int? Pin3Result { get; set; }

        public int? Pin4Result { get; set; }

        public string RowInsertTimeDisplay
        {
            get
            {
                return RowInsertTime.HasValue
                    ? RowInsertTime.Value.ToString(
                        "yyyy-MM-dd HH:mm:ss.fff",
                        CultureInfo.InvariantCulture)
                    : string.Empty;
            }
        }

        public string Pin1ResultDisplay =>
            FormatPinResult(Pin1Result);

        public string Pin2ResultDisplay =>
            FormatPinResult(Pin2Result);

        public string Pin3ResultDisplay =>
            FormatPinResult(Pin3Result);

        public string Pin4ResultDisplay =>
            FormatPinResult(Pin4Result);

        private static string FormatPinResult(int? result)
        {
            return result.HasValue
                ? result.Value.ToString(CultureInfo.InvariantCulture)
                : string.Empty;
        }
    }

    public class TcfOemDataViewModel
    {
        public TcfOemDataFilterModel Filter { get; set; } =
            new TcfOemDataFilterModel();

        public List<TcfOemDataDetailModel> Details { get; set; } =
            new List<TcfOemDataDetailModel>();

        public string ErrorMessage { get; set; } = string.Empty;
    }
}