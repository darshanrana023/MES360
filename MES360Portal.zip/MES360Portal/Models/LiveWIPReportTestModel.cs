using System;
using System.Collections.Generic;

namespace MES360Portal.Models
{
    public class LiveWIPSummaryCountModel
    {
        public int BIW { get; set; }
        public int WBS { get; set; }
        public int ED_To_Color_Selection { get; set; }
        public int Color_Selections_To_CQOK { get; set; }
        public int CQOK_To_Waxing { get; set; }
        public int Waxing_To_PBS { get; set; }
        public int TCF { get; set; }
    }

    public class LiveWIPDetailModel
    {
        public int Id { get; set; }
        public string VC { get; set; } = string.Empty;
        public string Model { get; set; } = string.Empty;
        public string Trim { get; set; } = string.Empty;
        public string EmmissionType { get; set; } = string.Empty;
        public string Colour { get; set; } = string.Empty;
        public string Fuel { get; set; } = string.Empty;
        public string Country { get; set; } = string.Empty;
        public int BIW { get; set; }
        public int WBS { get; set; }
        public int ED_To_Color_Selection { get; set; }
        public int Color_Selections_To_CQOK { get; set; }
        public int CQOK_To_Waxing { get; set; }
        public int Waxing_To_PBS { get; set; }
        public int TCF { get; set; }
    }

    public class LiveWIPReportTestViewModel
    {
        public LiveWIPSummaryCountModel SummaryCounts { get; set; } = new LiveWIPSummaryCountModel();
        public List<LiveWIPDetailModel> Details { get; set; } = new List<LiveWIPDetailModel>();
        public string ErrorMessage { get; set; } = string.Empty;
    }
}