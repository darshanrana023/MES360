using System.Collections.Generic;

namespace MES360Portal.Models
{
    public class AdminUserViewModel
    {
        public int UserId { get; set; }
        public string Username { get; set; } = string.Empty;
        public string FullName { get; set; } = string.Empty;
        public bool IsAdmin { get; set; }
        public List<TabPermissionModel> TabPermissions { get; set; } = new List<TabPermissionModel>();
    }

    public class TabPermissionModel
    {
        public string TabName { get; set; } = string.Empty;
        public bool CanAccess { get; set; }
    }
}