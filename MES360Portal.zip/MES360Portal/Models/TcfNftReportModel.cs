using System;
using System.Collections.Generic;

namespace MES360Portal.Models
{
    public class TcfNftFilterModel
    {
        public string Model { get; set; } = "ALL";

        public string Shift { get; set; } = "ALL";

        public DateTime? FromDate { get; set; }

        public string FromHour { get; set; } = "12";

        public string FromMin { get; set; } = "00";

        public string FromAmPm { get; set; } = "AM";

        public DateTime? ToDate { get; set; }

        public string ToHour { get; set; } = "11";

        public string ToMin { get; set; } = "59";

        public string ToAmPm { get; set; } = "PM";
    }

    public class TcfNftSummaryModel
    {
        public decimal TotalProduction { get; set; }

        public decimal TotalNftVehicles { get; set; }

        public decimal FsoPercentage { get; set; }
    }

    public class TcfNftDetailModel
    {
        public int SrNo { get; set; }

        public string Date { get; set; } = string.Empty;

        public string Time { get; set; } = string.Empty;

        public string Vin { get; set; } = string.Empty;

        public string Item { get; set; } = string.Empty;

        public string Defect { get; set; } = string.Empty;

        public string BookedAgainst { get; set; } = string.Empty;

        public string QaStatus { get; set; } = string.Empty;

        public string ReportedBy { get; set; } = string.Empty;
    }

    public class TcfNftTrendModel
    {
        public DateTime IntervalStart { get; set; }

        public DateTime IntervalEnd { get; set; }

        public string TimeSlot { get; set; } = string.Empty;

        public decimal TotalProduction { get; set; }

        public decimal TotalNftVehicles { get; set; }

        public decimal FsoPercentage { get; set; }
    }

    public class TcfNftViewModel
    {
        public TcfNftFilterModel Filter { get; set; } =
            new TcfNftFilterModel();

        public TcfNftSummaryModel Summary { get; set; } =
            new TcfNftSummaryModel();

        public List<TcfNftDetailModel> Details { get; set; } =
            new List<TcfNftDetailModel>();

        public List<TcfNftTrendModel> TrendData { get; set; } =
            new List<TcfNftTrendModel>();

        public string ErrorMessage { get; set; } = string.Empty;
    }
}