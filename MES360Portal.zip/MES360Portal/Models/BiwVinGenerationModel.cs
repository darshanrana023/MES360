using System;
using System.Collections.Generic;

namespace MES360Portal.Models
{
    public class BiwVinGenerationFilterModel
    {
        public string VinNumber { get; set; } = string.Empty;

        public string Model { get; set; } = "ALL";

        public string Shift { get; set; } = "ALL";

        public DateTime? FromDate { get; set; }

        public string FromHour { get; set; } = "12";

        public string FromMin { get; set; } = "00";

        public string FromAmPm { get; set; } = "AM";

        public DateTime? ToDate { get; set; }

        public string ToHour { get; set; } = "11";

        public string ToMin { get; set; } = "59";

        public string ToAmPm { get; set; } = "PM";
    }

    public class BiwShiftCountModel
    {
        public string ReportDate { get; set; } = string.Empty;

        public int A_Shift_BIW_IN { get; set; }

        public int A_Shift_BIW_OUT { get; set; }

        public int B_Shift_BIW_IN { get; set; }

        public int B_Shift_BIW_OUT { get; set; }

        public int C_Shift_BIW_IN { get; set; }

        public int C_Shift_BIW_OUT { get; set; }

        public int Total_BIW_IN { get; set; }

        public int Total_BIW_OUT { get; set; }
    }

    public class BiwVinGenerationDetailModel
    {
        public int SrNo { get; set; }

        public string RowInsertTime { get; set; } = string.Empty;

        public string TcfVinNumber { get; set; } = string.Empty;

        public string VcNumber { get; set; } = string.Empty;

        public string BiwOrderNumber { get; set; } = string.Empty;

        public string BiwSerialNumber { get; set; } = string.Empty;

        public string BiwPartNumber { get; set; } = string.Empty;

        public string BiwModel { get; set; } = string.Empty;

        public string BiwOrderStartTime { get; set; } = string.Empty;

        public string BiwOrderBookTime { get; set; } = string.Empty;

        public string BiwCqokTime { get; set; } = string.Empty;

        public string BiwCqokStatus { get; set; } = string.Empty;

        public string PntOrderNumber { get; set; } = string.Empty;

        public string PntSerialNumber { get; set; } = string.Empty;

        public string PntPartNumber { get; set; } = string.Empty;

        public string PntModel { get; set; } = string.Empty;

        public string PntColorName { get; set; } = string.Empty;

        public string PntOrderStartTime { get; set; } = string.Empty;

        public string PntOrderBookTime { get; set; } = string.Empty;

        public string PntCqokTime { get; set; } = string.Empty;

        public string PntCqaStatus { get; set; } = string.Empty;

        public string BiwVinGenerationTime { get; set; } = string.Empty;

        public string TcfVinModel { get; set; } = string.Empty;

        public string TcfVinModelRevision { get; set; } = string.Empty;

        public string TcfVinBarrelCode { get; set; } = string.Empty;

        public string TcfEmmissionType { get; set; } = string.Empty;

        public string TcfVinGenFormat { get; set; } = string.Empty;

        public string TcfVinDeleteFlag { get; set; } = string.Empty;

        public string TcfVinPbsColor { get; set; } = string.Empty;

        public string TcfVinPbsDateTime { get; set; } = string.Empty;

        public string EnginePartNo { get; set; } = string.Empty;
    }

    public class BiwVinGenerationViewModel
    {
        public BiwVinGenerationFilterModel Filter { get; set; } =
            new BiwVinGenerationFilterModel();

        public BiwShiftCountModel ShiftCount { get; set; } =
            new BiwShiftCountModel();

        public List<BiwVinGenerationDetailModel> Details { get; set; } =
            new List<BiwVinGenerationDetailModel>();

        public string ErrorMessage { get; set; } = string.Empty;
    }
}