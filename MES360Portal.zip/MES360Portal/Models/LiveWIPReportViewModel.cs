using System;
using System.Collections.Generic;

namespace MES360Portal.Models
{
    public class LiveWIPSummaryModel
    {
        public int BIW { get; set; }
        public int WBS { get; set; }
        public int ED_To_Color_Selection { get; set; }
        public int Color_Selections_To_PBS { get; set; }
        public int PBS { get; set; }
        public int TCF { get; set; }
    }

    public class LiveWIPDataModel
    {
        public int Id { get; set; }
        public string VC { get; set; } = string.Empty;
        public string Model { get; set; } = string.Empty;
        public string Trim { get; set; } = string.Empty;
        public string Colour { get; set; } = string.Empty;
        public string Fuel { get; set; } = string.Empty;
        public string Country { get; set; } = string.Empty;
        public int BIW { get; set; }
        public int WBS { get; set; }
        public int ED_To_Color_Selection { get; set; }
        public int Color_Selections_To_PBS { get; set; }
        public int PBS { get; set; }
        public int TCF { get; set; }
    }

    public class LiveWIPReportViewModel
    {
        public LiveWIPSummaryModel SummaryCounts { get; set; } = new LiveWIPSummaryModel();
        public List<LiveWIPDataModel> Details { get; set; } = new List<LiveWIPDataModel>();
        public string ErrorMessage { get; set; } = string.Empty;
    }
}