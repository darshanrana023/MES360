using System;
using System.Collections.Generic;

namespace MES360Portal.Models
{
    public class DailyOrderSummaryFilterModel
    {
        public string Plant { get; set; } = "7501";
        public string Shop { get; set; } = "TCF";
        public string Model { get; set; } = "ALL";
        public string Shift { get; set; } = "ALL";
        public DateTime? FromDate { get; set; }
        public string FromHour { get; set; } = "12";
        public string FromMin { get; set; } = "00";
        public string FromAmPm { get; set; } = "AM";
        public DateTime? ToDate { get; set; }
        public string ToHour { get; set; } = "11";
        public string ToMin { get; set; } = "59";
        public string ToAmPm { get; set; } = "PM";
    }

    public class DailyOrderSummaryDetailModel
    {
        public int SrNo { get; set; }
        public string Date { get; set; } = string.Empty;
        public int Dropped { get; set; }
        public int Booked { get; set; }
        public int ILCR { get; set; }
        public int QAOK { get; set; }
        public int SOK { get; set; }
    }

    public class DailyOrderSummaryViewModel
    {
        public DailyOrderSummaryFilterModel Filter { get; set; } = new DailyOrderSummaryFilterModel();
        public List<DailyOrderSummaryDetailModel> Details { get; set; } = new List<DailyOrderSummaryDetailModel>();
        public string ErrorMessage { get; set; } = string.Empty;
    }
}