using System;
using System.Collections.Generic;

namespace MES360Portal.Models
{
    public class IlcrReportFilterModel
    {
        public string Model { get; set; } = "ALL";
        public string EmmissionType { get; set; } = "ALL";
        public string Ilcr { get; set; } = "ALL";
        public string Age { get; set; } = "ALL";
    }

    public class IlcrReportDetailModel
    {
        public int SrNo { get; set; }
        public string Vin { get; set; } = string.Empty;
        public string Vc { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string EmmissionType { get; set; } = string.Empty;
        public string Colour { get; set; } = string.Empty;
        public string Model { get; set; } = string.Empty;
        public string BookingTime { get; set; } = string.Empty;
        public string Ilcr { get; set; } = string.Empty;
        public string Age { get; set; } = string.Empty;
    }

    public class IlcrReportViewModel
    {
        public IlcrReportFilterModel Filter { get; set; } = new IlcrReportFilterModel();
        
        // Filter options populated from distinct dataset values
        public List<string> ModelList { get; set; } = new List<string>();
        public List<string> EmmissionTypeList { get; set; } = new List<string>();
        public List<string> IlcrList { get; set; } = new List<string>();
        public List<string> AgeList { get; set; } = new List<string>();

        public List<IlcrReportDetailModel> Details { get; set; } = new List<IlcrReportDetailModel>();
        public string ErrorMessage { get; set; } = string.Empty;
    }
}