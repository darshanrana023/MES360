using System;
using System.Collections.Generic;

namespace MES360Portal.Models
{
    public class DailyOrderSummaryPartwiseFilterModel
    {
        public string Plant { get; set; } = "7501";
        public string Shop { get; set; } = "TCF";
        public string Model { get; set; } = "ALL";
        public string Shift { get; set; } = "ALL";
        public DateTime? FromDate { get; set; }
        public string FromHour { get; set; } = "12";
        public string FromMin { get; set; } = "00";
        public string FromAmPm { get; set; } = "AM";
        public DateTime? ToDate { get; set; }
        public string ToHour { get; set; } = "11";
        public string ToMin { get; set; } = "59";
        public string ToAmPm { get; set; } = "PM";
    }

    public class DailyOrderSummaryPartwiseDetailModel
    {
        public int SrNo { get; set; }
        public string PartNumber { get; set; } = string.Empty;
        public string Variant { get; set; } = string.Empty;
        public string Model { get; set; } = string.Empty;
        public string Emission { get; set; } = string.Empty;
        public string Color { get; set; } = string.Empty;
        public int OrderStart { get; set; }
        public int Booking { get; set; }
        public int QAOK { get; set; }
        public int SOK { get; set; }
    }

    public class DailyOrderSummaryPartwiseViewModel
    {
        public DailyOrderSummaryPartwiseFilterModel Filter { get; set; } = new DailyOrderSummaryPartwiseFilterModel();
        public List<DailyOrderSummaryPartwiseDetailModel> Details { get; set; } = new List<DailyOrderSummaryPartwiseDetailModel>();
        public string ErrorMessage { get; set; } = string.Empty;
    }
}