using System;
using System.Collections.Generic;

namespace MES360Portal.Models
{
    public class TcfVinGenerationFilterModel
    {
        public string Model { get; set; } = "ALL";
        public string Shift { get; set; } = "ALL";
        public DateTime? FromDate { get; set; }
        public string FromHour { get; set; } = "12";
        public string FromMin { get; set; } = "00";
        public string FromAmPm { get; set; } = "AM";
        public DateTime? ToDate { get; set; }
        public string ToHour { get; set; } = "11";
        public string ToMin { get; set; } = "59";
        public string ToAmPm { get; set; } = "PM";
    }

    public class TcfShiftCountModel
    {
        public string ReportDate { get; set; } = string.Empty;
        public int A_Shift_TCF_IN { get; set; }
        public int A_Shift_TCF_Rollout { get; set; }
        public int B_Shift_TCF_IN { get; set; }
        public int B_Shift_TCF_Rollout { get; set; }
        public int C_Shift_TCF_IN { get; set; }
        public int C_Shift_TCF_Rollout { get; set; }
        public int Total_TCF_IN { get; set; }
        public int Total_TCF_Rollout { get; set; }
    }

    public class TcfVinGenerationDetailModel
    {
        public int SrNo { get; set; }
        public string OrderNumber { get; set; } = string.Empty;
        public string Vin { get; set; } = string.Empty;
        public string VcNumber { get; set; } = string.Empty;
        public string VcDescription { get; set; } = string.Empty;
        public string EnginePartNumber { get; set; } = string.Empty;
        public string VentilationType { get; set; } = string.Empty;
        public string BiwNumber { get; set; } = string.Empty;
        public string ActualStartDate { get; set; } = string.Empty;
        public string ActualStartTime { get; set; } = string.Empty;
        public string Deleted { get; set; } = string.Empty;
        public string Country { get; set; } = string.Empty;
        public string HvacPartInfo { get; set; } = string.Empty;
    }

    public class TcfVinGenerationViewModel
    {
        public TcfVinGenerationFilterModel Filter { get; set; } = new TcfVinGenerationFilterModel();
        public TcfShiftCountModel ShiftCount { get; set; } = new TcfShiftCountModel();
        public List<TcfVinGenerationDetailModel> Details { get; set; } = new List<TcfVinGenerationDetailModel>();
        public string ErrorMessage { get; set; } = string.Empty;
    }
}