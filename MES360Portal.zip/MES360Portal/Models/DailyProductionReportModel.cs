using System;
using System.Data;

namespace MES360Portal.Models
{
    public class DailyProductionFilterModel
    {
        public string Model { get; set; } = "ALL";
        public DateTime? FromDate { get; set; }
        public string FromHour { get; set; } = "12";
        public string FromMin { get; set; } = "00";
        public string FromAmPm { get; set; } = "AM";
        public DateTime? ToDate { get; set; }
        public string ToHour { get; set; } = "11";
        public string ToMin { get; set; } = "59";
        public string ToAmPm { get; set; } = "PM";
    }

    public class DailyProductionReportViewModel
    {
        public DailyProductionFilterModel Filter { get; set; } = new DailyProductionFilterModel();
        public DataTable ReportData { get; set; } = new DataTable();
        public string ErrorMessage { get; set; } = string.Empty;
    }
}