using System;
using System.Collections.Generic;

namespace MES360Portal.Models
{
    public class TcfEolDrrFilterModel
    {
        public string Station { get; set; } = "CANOPY";
        public string Model { get; set; } = "ALL";
        public string Shift { get; set; } = "ALL";
        public DateTime? FromDate { get; set; }
        public string FromHour { get; set; } = "12";
        public string FromMin { get; set; } = "00";
        public string FromAmPm { get; set; } = "AM";
        public DateTime? ToDate { get; set; }
        public string ToHour { get; set; } = "11";
        public string ToMin { get; set; } = "59";
        public string ToAmPm { get; set; } = "PM";
    }

    public class TcfEolDrrDetailModel
    {
        public int SrNo { get; set; }
        public long Id { get; set; }
        public string Date { get; set; } = string.Empty;
        public decimal DRR { get; set; }
        public int NoOfOfflineVehicle { get; set; }
        public int TotalVinInspected { get; set; }
        public string Target { get; set; } = string.Empty;
    }

    public class TcfEolDrrViewModel
    {
        public TcfEolDrrFilterModel Filter { get; set; } = new TcfEolDrrFilterModel();
        public List<TcfEolDrrDetailModel> Details { get; set; } = new List<TcfEolDrrDetailModel>();
        public string ErrorMessage { get; set; } = string.Empty;
    }
}