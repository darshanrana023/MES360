using System;
using System.Collections.Generic;

namespace MES360Portal.Models
{
    public class QGWiseTrackingDetailModel
    {
        public int SrNo { get; set; }
        public string Shop { get; set; } = string.Empty;
        public string Station { get; set; } = string.Empty;
        public string Date { get; set; } = string.Empty;
        public string Time { get; set; } = string.Empty;
    }

    public class QGWiseTrackingReportViewModel
    {
        public string VinNumber { get; set; } = string.Empty;
        public List<QGWiseTrackingDetailModel> Details { get; set; } = new List<QGWiseTrackingDetailModel>();
        public string ErrorMessage { get; set; } = string.Empty;
    }
}