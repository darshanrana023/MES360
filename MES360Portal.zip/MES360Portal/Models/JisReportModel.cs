using System;
using System.Collections.Generic;

namespace MES360Portal.Models
{
    public class JisReportDetailModel
    {
        public int SrNo { get; set; }
        public string Dsn { get; set; } = string.Empty;
        public string Vin { get; set; } = string.Empty;
        public string VcNumber { get; set; } = string.Empty;
        public string VcDescription { get; set; } = string.Empty;
        public string VcColor { get; set; } = string.Empty;
        public string CarType { get; set; } = string.Empty;
        public string ActualVinGenDate { get; set; } = string.Empty;
        public string ActualVinGenTime { get; set; } = string.Empty;
        public string Quantity { get; set; } = string.Empty;
        public string PaintedBodyPartNumber { get; set; } = string.Empty;
        public string EnginePartNumber { get; set; } = string.Empty;
        public string FuelType { get; set; } = string.Empty;
        public string EmissionType { get; set; } = string.Empty;
        public string TransmissionType { get; set; } = string.Empty;
        public string VentilationType { get; set; } = string.Empty;
        public string TrimLevel { get; set; } = string.Empty;
        public string Location { get; set; } = string.Empty;
    }

    public class JisReportViewModel
    {
        public List<JisReportDetailModel> Details { get; set; } = new List<JisReportDetailModel>();
        public string ErrorMessage { get; set; } = string.Empty;
    }
}