using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using MES360Portal.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace MES360Portal.Repository
{
    public class OrderInMESRepository
    {
        private readonly IConfiguration _configuration;

        public OrderInMESRepository(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public OrderInMESViewModel GetOrderInMESReport(OrderInMESFilterModel filter)
        {
            filter ??= new OrderInMESFilterModel();

            var viewModel = new OrderInMESViewModel
            {
                Filter = filter,
                Details = new List<OrderInMESDetailModel>()
            };

            try
            {
                string shift = NormalizeShift(filter.Shift);
                string model = string.IsNullOrWhiteSpace(filter.Model) ? "ALL" : filter.Model.Trim().ToUpperInvariant();
                string shop = string.IsNullOrWhiteSpace(filter.Shop) ? "Engine" : filter.Shop.Trim();
                string plant = string.IsNullOrWhiteSpace(filter.Plant) ? "7501" : filter.Plant.Trim();
                string orderState = string.IsNullOrWhiteSpace(filter.OrderState) ? "ALL" : filter.OrderState.Trim();
                string qualityState = string.IsNullOrWhiteSpace(filter.QualityState) ? "ALL" : filter.QualityState.Trim();

                filter.Shift = shift;
                filter.Model = model;
                filter.Shop = shop;
                filter.Plant = plant;
                filter.OrderState = orderState;
                filter.QualityState = qualityState;

                (DateTime startDateTime, DateTime endDateTime) = ResolveDateTimeRange(filter, shift);

                viewModel.Details = GetOrderInMESDetails(shop, orderState, qualityState, startDateTime, endDateTime, model);
            }
            catch (Exception ex)
            {
                viewModel.ErrorMessage = ex.Message;
            }

            return viewModel;
        }

        private List<OrderInMESDetailModel> GetOrderInMESDetails(
            string shop,
            string state,
            string qualityState,
            DateTime startDateTime,
            DateTime endDateTime,
            string model)
        {
            var details = new List<OrderInMESDetailModel>();

            using SqlConnection connection = CreateMesDbConnection();
            using SqlCommand command = new SqlCommand("dbo.SAN_OrderInMES", connection);

            command.CommandType = CommandType.StoredProcedure;
            command.CommandTimeout = 120;

            command.Parameters.Add("@shop", SqlDbType.VarChar, 50).Value = shop;
            command.Parameters.Add("@state", SqlDbType.VarChar, 50).Value = state;
            command.Parameters.Add("@QualityState", SqlDbType.VarChar, 50).Value = qualityState;
            command.Parameters.Add("@StartDate", SqlDbType.VarChar, 30).Value = startDateTime.ToString("yyyy-MM-dd HH:mm:ss");
            command.Parameters.Add("@EndDate", SqlDbType.VarChar, 30).Value = endDateTime.ToString("yyyy-MM-dd HH:mm:ss");
            command.Parameters.Add("@Model", SqlDbType.VarChar, 50).Value = model;

            using SqlDataAdapter adapter = new SqlDataAdapter(command);
            var dataTable = new DataTable();
            adapter.Fill(dataTable);

            int counter = 1;

            foreach (DataRow row in dataTable.Rows)
            {
                var item = new OrderInMESDetailModel
                {
                    SrNo = counter,
                    OrderNumber = FormatString(GetValue(row, "Order Number", "OrderNumber")),
                    PartNumber = FormatString(GetValue(row, "Part Number", "PartNumber")),
                    SerialNumber = FormatString(GetValue(row, "Serial Number", "SerialNumber")),
                    Model = FormatString(GetValue(row, "Model")),
                    Emission = FormatString(GetValue(row, "Emission")),
                    Color = FormatString(GetValue(row, "Color")),
                    StartTime = FormatDateTime(GetValue(row, "Start Time", "StartTime")),
                    BookingTime = FormatDateTime(GetValue(row, "Booking time", "BookingTime", "Booking Time")),
                    ProdQAOKTime = FormatDateTime(GetValue(row, "ProdQAOK Time", "ProdQAOKTime")),
                    QAOKTime = FormatDateTime(GetValue(row, "QAOK Time", "QAOKTime")),
                    ClosedTime = FormatDateTime(GetValue(row, "Closed time", "ClosedTime", "Closed Time")),
                    OrderState = FormatString(GetValue(row, "Order State", "OrderState"))
                };

                details.Add(item);
                counter++;
            }

            return details;
        }

        private static (DateTime StartDateTime, DateTime EndDateTime) ResolveDateTimeRange(
            OrderInMESFilterModel filter, string shift)
        {
            if (shift == "ALL")
            {
                DateTime startDateTime = BuildDateTime(filter.FromDate, filter.FromHour, filter.FromMin, filter.FromAmPm);
                DateTime endDateTime = BuildDateTime(filter.ToDate, filter.ToHour, filter.ToMin, filter.ToAmPm);

                if (endDateTime <= startDateTime)
                {
                    throw new ArgumentException("To Date and Time must be later than From Date and Time.");
                }

                return (startDateTime, endDateTime);
            }

            DateTime selectedDate = filter.FromDate?.Date ?? filter.ToDate?.Date ?? DateTime.Today;

            switch (shift)
            {
                case "A":
                    UpdateFilterForShift(filter, selectedDate, selectedDate, "06", "30", "AM", "03", "00", "PM");
                    return (selectedDate.AddHours(6).AddMinutes(30), selectedDate.AddHours(15));
                case "B":
                    UpdateFilterForShift(filter, selectedDate, selectedDate, "03", "00", "PM", "11", "30", "PM");
                    return (selectedDate.AddHours(15), selectedDate.AddHours(23).AddMinutes(30));
                case "C":
                    UpdateFilterForShift(filter, selectedDate, selectedDate.AddDays(1), "11", "30", "PM", "06", "30", "AM");
                    return (selectedDate.AddHours(23).AddMinutes(30), selectedDate.AddDays(1).AddHours(6).AddMinutes(30));
                default:
                    throw new ArgumentException("Shift must be ALL, A, B, or C.");
            }
        }

        private static void UpdateFilterForShift(
            OrderInMESFilterModel filter, DateTime fromDate, DateTime toDate,
            string fromHour, string fromMinute, string fromAmPm,
            string toHour, string toMinute, string toAmPm)
        {
            filter.FromDate = fromDate;
            filter.FromHour = fromHour;
            filter.FromMin = fromMinute;
            filter.FromAmPm = fromAmPm;
            filter.ToDate = toDate;
            filter.ToHour = toHour;
            filter.ToMin = toMinute;
            filter.ToAmPm = toAmPm;
        }

        private static DateTime BuildDateTime(DateTime? date, string? hour, string? minute, string? amPm)
        {
            DateTime selectedDate = date?.Date ?? DateTime.Today;
            int selectedHour = ParseTimeValue(hour, "hour", 1, 12);
            int selectedMinute = ParseTimeValue(minute, "minute", 0, 59);
            string normalizedAmPm = NormalizeAmPm(amPm);

            if (normalizedAmPm == "PM" && selectedHour != 12) selectedHour += 12;
            if (normalizedAmPm == "AM" && selectedHour == 12) selectedHour = 0;

            return new DateTime(selectedDate.Year, selectedDate.Month, selectedDate.Day, selectedHour, selectedMinute, 0);
        }

        private static int ParseTimeValue(string? value, string fieldName, int minimum, int maximum)
        {
            if (!int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out int result))
                throw new ArgumentException($"Invalid {fieldName} value.");

            if (result < minimum || result > maximum)
                throw new ArgumentOutOfRangeException(fieldName, $"{fieldName} must be between {minimum} and {maximum}.");

            return result;
        }

        private static string NormalizeAmPm(string? amPm)
        {
            string normalized = (amPm ?? string.Empty).Trim().ToUpperInvariant();
            if (normalized != "AM" && normalized != "PM") throw new ArgumentException("AM/PM value must be AM or PM.");
            return normalized;
        }

        private static string NormalizeShift(string? shift)
        {
            string normalized = string.IsNullOrWhiteSpace(shift) ? "ALL" : shift.Trim().ToUpperInvariant();
            if (normalized != "ALL" && normalized != "A" && normalized != "B" && normalized != "C")
                throw new ArgumentException("Shift must be ALL, A, B, or C.");
            return normalized;
        }

        private SqlConnection CreateMesDbConnection()
        {
            string? connectionString = _configuration.GetConnectionString("MESDB");
            if (string.IsNullOrWhiteSpace(connectionString))
                throw new InvalidOperationException("The MESDB connection string is missing or empty.");
            return new SqlConnection(connectionString);
        }

        private static object? GetValue(DataRow row, params string[] columnNames)
        {
            foreach (string name in columnNames)
            {
                DataColumn? matched = row.Table.Columns.Cast<DataColumn>()
                    .FirstOrDefault(c => string.Equals(c.ColumnName.Trim(), name.Trim(), StringComparison.OrdinalIgnoreCase));
                if (matched != null) return row[matched] == DBNull.Value ? null : row[matched];
            }
            return null;
        }

        private static string FormatString(object? val)
        {
            if (val == null || val == DBNull.Value) return "";
            string res = Convert.ToString(val) ?? "";
            return res.Equals("NULL", StringComparison.OrdinalIgnoreCase) ? "" : res;
        }

        private static string FormatDateTime(object? val)
        {
            if (val == null || val == DBNull.Value) return "";
            if (DateTime.TryParse(Convert.ToString(val), out DateTime dt))
            {
                return dt.ToString("yyyy-MM-dd HH:mm:ss");
            }
            string str = Convert.ToString(val) ?? "";
            return str.Equals("NULL", StringComparison.OrdinalIgnoreCase) ? "" : str;
        }
    }
}