using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using MES360Portal.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace MES360Portal.Repository
{
    public class TcfNftRepository
    {
        private readonly IConfiguration _configuration;

        public TcfNftRepository(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public TcfNftViewModel GetTcfNftReport(TcfNftFilterModel filter)
        {
            filter ??= new TcfNftFilterModel();

            var viewModel = new TcfNftViewModel
            {
                Filter = filter,
                Summary = new TcfNftSummaryModel(),
                Details = new List<TcfNftDetailModel>(),
                TrendData = new List<TcfNftTrendModel>()
            };

            try
            {
                string shift = NormalizeShift(filter.Shift);
                string model = NormalizeModel(filter.Model);

                filter.Shift = shift;
                filter.Model = model;

                (DateTime fromDateTime, DateTime toDateTime) = ResolveDateTimeRange(filter, shift);

                // 1. Get Total Production (Single Query)
                viewModel.Summary.TotalProduction = GetTotalProduction(
                    fromDateTime,
                    toDateTime,
                    model
                );

                // 2. Get Total NFT Vehicles (Single Stored Procedure Call)
                viewModel.Summary.TotalNftVehicles = GetTotalNftVehicles(
                    fromDateTime,
                    toDateTime,
                    model
                );

                // 3. Calculate FSO Percentage
                viewModel.Summary.FsoPercentage = CalculateFsoPercentage(
                    viewModel.Summary.TotalProduction,
                    viewModel.Summary.TotalNftVehicles
                );

                // 4. Get Grid Details (Single Stored Procedure Call)
                viewModel.Details = GetNftDetails(
                    fromDateTime,
                    toDateTime,
                    model
                );

                // Note: Hourly trend loop removed to restore 2-3s high performance.
            }
            catch (Exception ex)
            {
                viewModel.ErrorMessage = ex.Message;
            }

            return viewModel;
        }

        private decimal GetTotalProduction(DateTime fromDateTime, DateTime toDateTime, string model)
        {
            const string query = @"
                SELECT COUNT(1)
                FROM dbo.UDA_Order
                WHERE SID_S = '54'
                  AND plant_s = '7501'
                  AND line_number_s = '1'
                  AND orderendtime_t >= @FromDateTime
                  AND orderendtime_t < @ToDateTime
                  AND
                  (
                      ISNULL(ProductVariant_S, 'NANO') LIKE
                      CASE
                          WHEN @Model = 'ALL' THEN '%'
                          WHEN @Model = 'TIAGO' THEN 'KITE'
                          ELSE @Model
                      END
                      OR
                      ProductVariant_S LIKE
                      CASE
                          WHEN @Model = 'TIAGO' THEN 'TIAGO'
                          ELSE ''
                      END
                  );";

            using SqlConnection connection = CreateConnection();
            using SqlCommand command = new SqlCommand(query, connection);

            command.CommandType = CommandType.Text;
            command.CommandTimeout = 30;

            command.Parameters.Add("@FromDateTime", SqlDbType.DateTime2).Value = fromDateTime;
            command.Parameters.Add("@ToDateTime", SqlDbType.DateTime2).Value = toDateTime;
            command.Parameters.Add("@Model", SqlDbType.VarChar, 50).Value = model;

            connection.Open();
            object? result = command.ExecuteScalar();

            if (result == null || result == DBNull.Value)
            {
                return 0;
            }

            return Convert.ToDecimal(result, CultureInfo.InvariantCulture);
        }

        private decimal GetTotalNftVehicles(DateTime fromDateTime, DateTime toDateTime, string model)
        {
            using SqlConnection connection = CreateConnection();
            using SqlCommand command = new SqlCommand("SAN_NFTCount", connection);

            command.CommandType = CommandType.StoredProcedure;
            command.CommandTimeout = 30;

            command.Parameters.Add("@start", SqlDbType.DateTime).Value = fromDateTime;
            command.Parameters.Add("@end", SqlDbType.DateTime).Value = GetStoredProcedureEndDateTime(toDateTime);
            command.Parameters.Add("@variant", SqlDbType.VarChar, 10).Value = model;

            connection.Open();
            object? result = command.ExecuteScalar();

            if (result == null || result == DBNull.Value)
            {
                return 0;
            }

            return Convert.ToDecimal(result, CultureInfo.InvariantCulture);
        }

        private List<TcfNftDetailModel> GetNftDetails(DateTime fromDateTime, DateTime toDateTime, string model)
        {
            var details = new List<TcfNftDetailModel>();

            using SqlConnection connection = CreateConnection();
            using SqlCommand command = new SqlCommand("SAN_NFT", connection);

            command.CommandType = CommandType.StoredProcedure;
            command.CommandTimeout = 30;

            command.Parameters.Add("@start", SqlDbType.DateTime).Value = fromDateTime;
            command.Parameters.Add("@end", SqlDbType.DateTime).Value = GetStoredProcedureEndDateTime(toDateTime);
            command.Parameters.Add("@Model", SqlDbType.VarChar, 40).Value = model;

            using SqlDataAdapter adapter = new SqlDataAdapter(command);
            var dataTable = new DataTable();
            adapter.Fill(dataTable);

            int counter = 1;
            foreach (DataRow row in dataTable.Rows)
            {
                var item = new TcfNftDetailModel
                {
                    SrNo = GetInt(row, "Sr.No.", "SrNo", "Sr.No", "SrNo."),
                    Date = FormatDateValue(GetValue(row, "Date")),
                    Time = GetString(row, "Time"),
                    Vin = GetString(row, "VIN", "Vin"),
                    Item = GetString(row, "Item"),
                    Defect = GetString(row, "Defect"),
                    BookedAgainst = GetString(row, "Booked Against", "BookedAgainst", "Booked_Against"),
                    QaStatus = GetString(row, "Current QA Status", "QA Status", "QAStatus", "QaStatus", "QA_Status", "Status"),
                    ReportedBy = GetString(row, "Reported By", "ReportedBy", "Reported_By")
                };

                if (item.SrNo <= 0)
                {
                    item.SrNo = counter;
                }

                details.Add(item);
                counter++;
            }

            return details;
        }

        private static (DateTime FromDateTime, DateTime ToDateTime) ResolveDateTimeRange(TcfNftFilterModel filter, string shift)
        {
            if (shift == "ALL")
            {
                DateTime fromDateTime = BuildDateTime(filter.FromDate, filter.FromHour, filter.FromMin, filter.FromAmPm, true);
                DateTime toDateTime = BuildDateTime(filter.ToDate, filter.ToHour, filter.ToMin, filter.ToAmPm, false);

                if (toDateTime <= fromDateTime)
                {
                    throw new ArgumentException("To Date and Time must be later than From Date and Time.");
                }

                return (fromDateTime, toDateTime);
            }

            DateTime selectedDate = filter.FromDate?.Date ?? filter.ToDate?.Date ?? DateTime.Today;

            switch (shift)
            {
                case "A":
                    UpdateFilterForShift(filter, selectedDate, selectedDate, "06", "30", "AM", "03", "00", "PM");
                    return (selectedDate.AddHours(6).AddMinutes(30), selectedDate.AddHours(15));

                case "B":
                    UpdateFilterForShift(filter, selectedDate, selectedDate, "03", "00", "PM", "11", "30", "PM");
                    return (selectedDate.AddHours(15), selectedDate.AddHours(23).AddMinutes(30));

                case "C":
                    UpdateFilterForShift(filter, selectedDate, selectedDate.AddDays(1), "11", "30", "PM", "06", "30", "AM");
                    return (selectedDate.AddHours(23).AddMinutes(30), selectedDate.AddDays(1).AddHours(6).AddMinutes(30));

                default:
                    throw new ArgumentException("Shift must be ALL, A, B, or C.");
            }
        }

        private static void UpdateFilterForShift(TcfNftFilterModel filter, DateTime fromDate, DateTime toDate, string fromHour, string fromMinute, string fromAmPm, string toHour, string toMinute, string toAmPm)
        {
            filter.FromDate = fromDate;
            filter.FromHour = fromHour;
            filter.FromMin = fromMinute;
            filter.FromAmPm = fromAmPm;

            filter.ToDate = toDate;
            filter.ToHour = toHour;
            filter.ToMin = toMinute;
            filter.ToAmPm = toAmPm;
        }

        private static DateTime BuildDateTime(DateTime? date, string? hour, string? minute, string? amPm, bool isFromDate)
        {
            DateTime selectedDate = date?.Date ?? DateTime.Today;
            int selectedHour = ParseTimeValue(hour, "hour", 1, 12);
            int selectedMinute = ParseTimeValue(minute, "minute", 0, 59);
            string normalizedAmPm = NormalizeAmPm(amPm);

            if (normalizedAmPm == "PM" && selectedHour != 12) selectedHour += 12;
            if (normalizedAmPm == "AM" && selectedHour == 12) selectedHour = 0;

            DateTime selectedDateTime = new DateTime(selectedDate.Year, selectedDate.Month, selectedDate.Day, selectedHour, selectedMinute, 0);

            if (!isFromDate)
            {
                selectedDateTime = selectedDateTime.AddMinutes(1);
            }

            return selectedDateTime;
        }

        private static int ParseTimeValue(string? value, string fieldName, int minimum, int maximum)
        {
            if (!int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out int result) || result < minimum || result > maximum)
            {
                throw new ArgumentException($"Invalid {fieldName} value.");
            }
            return result;
        }

        private static string NormalizeAmPm(string? amPm)
        {
            string val = (amPm ?? string.Empty).Trim().ToUpperInvariant();
            return val == "AM" || val == "PM" ? val : throw new ArgumentException("AM/PM value must be AM or PM.");
        }

        private static string NormalizeShift(string? shift)
        {
            string val = string.IsNullOrWhiteSpace(shift) ? "ALL" : shift.Trim().ToUpperInvariant();
            return val == "ALL" || val == "A" || val == "B" || val == "C" ? val : throw new ArgumentException("Shift must be ALL, A, B, or C.");
        }

        private static string NormalizeModel(string? model)
        {
            if (string.IsNullOrWhiteSpace(model)) return "ALL";
            string val = model.Trim().ToUpperInvariant();
            return val switch
            {
                "ALL" => "ALL",
                "TIAGO" => "TIAGO",
                "KITE5" => "KITE5",
                "NANO" => "NANO",
                _ => val
            };
        }

        private static decimal CalculateFsoPercentage(decimal totalProduction, decimal totalNftVehicles)
        {
            if (totalProduction <= 0) return 0;
            decimal fsoPercentage = ((totalProduction - totalNftVehicles) / totalProduction) * 100;
            return Math.Round(fsoPercentage, 2, MidpointRounding.AwayFromZero);
        }

        private SqlConnection CreateConnection()
        {
            string? connectionString = _configuration.GetConnectionString("MESDB");
            if (string.IsNullOrWhiteSpace(connectionString))
            {
                throw new InvalidOperationException("The MESDB connection string is missing or empty.");
            }
            return new SqlConnection(connectionString);
        }

        private static DateTime GetStoredProcedureEndDateTime(DateTime exclusiveToDateTime)
        {
            return exclusiveToDateTime.AddMilliseconds(-1);
        }

        private static object? GetValue(DataRow row, params string[] columnNames)
        {
            DataColumn? matchedColumn = FindColumn(row.Table, columnNames);
            return matchedColumn == null || row[matchedColumn] == DBNull.Value ? null : row[matchedColumn];
        }

        private static string FormatDateValue(object? value)
        {
            if (value == null) return string.Empty;
            if (value is DateTime dt) return dt.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
            string str = Convert.ToString(value, CultureInfo.InvariantCulture) ?? string.Empty;
            return DateTime.TryParse(str, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime parsed) ? parsed.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture) : str;
        }

        private static string GetString(DataRow row, params string[] columnNames)
        {
            object? val = GetValue(row, columnNames);
            return val == null ? string.Empty : Convert.ToString(val, CultureInfo.InvariantCulture) ?? string.Empty;
        }

        private static int GetInt(DataRow row, params string[] columnNames)
        {
            object? val = GetValue(row, columnNames);
            if (val == null) return 0;
            if (val is int i) return i;
            if (val is long l) return checked((int)l);
            if (val is decimal d) return Convert.ToInt32(d);
            return int.TryParse(Convert.ToString(val, CultureInfo.InvariantCulture), out int parsed) ? parsed : 0;
        }

        private static DataColumn? FindColumn(DataTable table, params string[] columnNames)
        {
            foreach (string colName in columnNames)
            {
                DataColumn? match = table.Columns.Cast<DataColumn>().FirstOrDefault(c => string.Equals(c.ColumnName.Trim(), colName.Trim(), StringComparison.OrdinalIgnoreCase));
                if (match != null) return match;
            }
            return null;
        }
    }
}