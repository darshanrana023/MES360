using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using MES360Portal.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace MES360Portal.Repository
{
    public class DailyOrderSummaryPartwiseRepository
    {
        private readonly IConfiguration _configuration;

        public DailyOrderSummaryPartwiseRepository(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public DailyOrderSummaryPartwiseViewModel GetDailyOrderSummaryPartwiseReport(DailyOrderSummaryPartwiseFilterModel filter)
        {
            filter ??= new DailyOrderSummaryPartwiseFilterModel();

            var viewModel = new DailyOrderSummaryPartwiseViewModel
            {
                Filter = filter,
                Details = new List<DailyOrderSummaryPartwiseDetailModel>()
            };

            try
            {
                string shift = NormalizeShift(filter.Shift);
                string model = string.IsNullOrWhiteSpace(filter.Model) ? "ALL" : filter.Model.Trim().ToUpperInvariant();
                string shop = string.IsNullOrWhiteSpace(filter.Shop) ? "TCF" : filter.Shop.Trim();
                string plant = string.IsNullOrWhiteSpace(filter.Plant) ? "7501" : filter.Plant.Trim();

                filter.Shift = shift;
                filter.Model = model;
                filter.Shop = shop;
                filter.Plant = plant;

                (DateTime startDateTime, DateTime endDateTime) = ResolveDateTimeRange(filter, shift);

                viewModel.Details = GetDailyOrderSummaryPartwiseDetails(shop, startDateTime, endDateTime, model);
            }
            catch (Exception ex)
            {
                viewModel.ErrorMessage = ex.Message;
            }

            return viewModel;
        }

        private List<DailyOrderSummaryPartwiseDetailModel> GetDailyOrderSummaryPartwiseDetails(
            string shop,
            DateTime startDateTime,
            DateTime endDateTime,
            string model)
        {
            var details = new List<DailyOrderSummaryPartwiseDetailModel>();

            using SqlConnection connection = CreateMesDbConnection();
            using SqlCommand command = new SqlCommand("dbo.DailyOrderSummary_partwise_new", connection);

            command.CommandType = CommandType.StoredProcedure;
            command.CommandTimeout = 120;

            command.Parameters.Add("@Shop", SqlDbType.VarChar, 30).Value = shop;
            command.Parameters.Add("@StartDate", SqlDbType.VarChar, 30).Value = startDateTime.ToString("yyyy-MM-dd HH:mm:ss");
            command.Parameters.Add("@EndDate", SqlDbType.VarChar, 30).Value = endDateTime.ToString("yyyy-MM-dd HH:mm:ss");
            command.Parameters.Add("@Model", SqlDbType.VarChar, 40).Value = model;

            using SqlDataAdapter adapter = new SqlDataAdapter(command);
            var dataTable = new DataTable();
            adapter.Fill(dataTable);

            int counter = 1;

            foreach (DataRow row in dataTable.Rows)
            {
                var item = new DailyOrderSummaryPartwiseDetailModel
                {
                    SrNo = counter,
                    PartNumber = Convert.ToString(GetValue(row, "PartNumber")) ?? string.Empty,
                    Variant = Convert.ToString(GetValue(row, "Variant")) ?? string.Empty,
                    Model = Convert.ToString(GetValue(row, "Model")) ?? string.Empty,
                    Emission = Convert.ToString(GetValue(row, "Emission")) ?? string.Empty,
                    Color = Convert.ToString(GetValue(row, "Color")) ?? string.Empty,
                    OrderStart = GetInt(row, "Order Start", "OrderStart"),
                    Booking = GetInt(row, "Booking"),
                    QAOK = GetInt(row, "QAOK"),
                    SOK = GetInt(row, "SOK")
                };

                details.Add(item);
                counter++;
            }

            return details;
        }

        private static (DateTime StartDateTime, DateTime EndDateTime) ResolveDateTimeRange(
            DailyOrderSummaryPartwiseFilterModel filter, string shift)
        {
            if (shift == "ALL")
            {
                DateTime startDateTime = BuildDateTime(filter.FromDate, filter.FromHour, filter.FromMin, filter.FromAmPm);
                DateTime endDateTime = BuildDateTime(filter.ToDate, filter.ToHour, filter.ToMin, filter.ToAmPm);

                if (endDateTime <= startDateTime)
                {
                    throw new ArgumentException("To Date and Time must be later than From Date and Time.");
                }

                return (startDateTime, endDateTime);
            }

            DateTime selectedDate = filter.FromDate?.Date ?? filter.ToDate?.Date ?? DateTime.Today;

            switch (shift)
            {
                case "A":
                    UpdateFilterForShift(filter, selectedDate, selectedDate, "06", "30", "AM", "03", "00", "PM");
                    return (selectedDate.AddHours(6).AddMinutes(30), selectedDate.AddHours(15));
                case "B":
                    UpdateFilterForShift(filter, selectedDate, selectedDate, "03", "00", "PM", "11", "30", "PM");
                    return (selectedDate.AddHours(15), selectedDate.AddHours(23).AddMinutes(30));
                case "C":
                    UpdateFilterForShift(filter, selectedDate, selectedDate.AddDays(1), "11", "30", "PM", "06", "30", "AM");
                    return (selectedDate.AddHours(23).AddMinutes(30), selectedDate.AddDays(1).AddHours(6).AddMinutes(30));
                default:
                    throw new ArgumentException("Shift must be ALL, A, B, or C.");
            }
        }

        private static void UpdateFilterForShift(
            DailyOrderSummaryPartwiseFilterModel filter, DateTime fromDate, DateTime toDate,
            string fromHour, string fromMinute, string fromAmPm,
            string toHour, string toMinute, string toAmPm)
        {
            filter.FromDate = fromDate;
            filter.FromHour = fromHour;
            filter.FromMin = fromMinute;
            filter.FromAmPm = fromAmPm;
            filter.ToDate = toDate;
            filter.ToHour = toHour;
            filter.ToMin = toMinute;
            filter.ToAmPm = toAmPm;
        }

        private static DateTime BuildDateTime(DateTime? date, string? hour, string? minute, string? amPm)
        {
            DateTime selectedDate = date?.Date ?? DateTime.Today;
            int selectedHour = ParseTimeValue(hour, "hour", 1, 12);
            int selectedMinute = ParseTimeValue(minute, "minute", 0, 59);
            string normalizedAmPm = NormalizeAmPm(amPm);

            if (normalizedAmPm == "PM" && selectedHour != 12) selectedHour += 12;
            if (normalizedAmPm == "AM" && selectedHour == 12) selectedHour = 0;

            return new DateTime(selectedDate.Year, selectedDate.Month, selectedDate.Day, selectedHour, selectedMinute, 0);
        }

        private static int ParseTimeValue(string? value, string fieldName, int minimum, int maximum)
        {
            if (!int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out int result))
                throw new ArgumentException($"Invalid {fieldName} value.");

            if (result < minimum || result > maximum)
                throw new ArgumentOutOfRangeException(fieldName, $"{fieldName} must be between {minimum} and {maximum}.");

            return result;
        }

        private static string NormalizeAmPm(string? amPm)
        {
            string normalized = (amPm ?? string.Empty).Trim().ToUpperInvariant();
            if (normalized != "AM" && normalized != "PM") throw new ArgumentException("AM/PM value must be AM or PM.");
            return normalized;
        }

        private static string NormalizeShift(string? shift)
        {
            string normalized = string.IsNullOrWhiteSpace(shift) ? "ALL" : shift.Trim().ToUpperInvariant();
            if (normalized != "ALL" && normalized != "A" && normalized != "B" && normalized != "C")
                throw new ArgumentException("Shift must be ALL, A, B, or C.");
            return normalized;
        }

        private SqlConnection CreateMesDbConnection()
        {
            string? connectionString = _configuration.GetConnectionString("MESDB");
            if (string.IsNullOrWhiteSpace(connectionString))
                throw new InvalidOperationException("The MESDB connection string is missing or empty.");
            return new SqlConnection(connectionString);
        }

        private static object? GetValue(DataRow row, params string[] columnNames)
        {
            foreach (string name in columnNames)
            {
                DataColumn? matched = row.Table.Columns.Cast<DataColumn>()
                    .FirstOrDefault(c => string.Equals(c.ColumnName.Trim(), name.Trim(), StringComparison.OrdinalIgnoreCase));
                if (matched != null) return row[matched] == DBNull.Value ? null : row[matched];
            }
            return null;
        }

        private static int GetInt(DataRow row, params string[] columnNames)
        {
            object? value = GetValue(row, columnNames);
            if (value == null) return 0;
            if (value is int integerValue) return integerValue;
            if (int.TryParse(Convert.ToString(value, CultureInfo.InvariantCulture), out int parsedValue)) return parsedValue;
            return 0;
        }
    }
}