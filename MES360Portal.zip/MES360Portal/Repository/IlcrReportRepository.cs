using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using MES360Portal.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace MES360Portal.Repository
{
    public class IlcrReportRepository
    {
        private readonly IConfiguration _configuration;

        public IlcrReportRepository(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public IlcrReportViewModel GetIlcrReport(IlcrReportFilterModel? filter = null)
        {
            filter ??= new IlcrReportFilterModel();

            var viewModel = new IlcrReportViewModel
            {
                Filter = filter,
                Details = new List<IlcrReportDetailModel>()
            };

            try
            {
                using SqlConnection connection = CreateMesDbConnection();
                using SqlCommand command = new SqlCommand("SAN_ILCR", connection);

                command.CommandType = CommandType.StoredProcedure;
                command.CommandTimeout = 120;

                using SqlDataAdapter adapter = new SqlDataAdapter(command);
                var dataTable = new DataTable();
                adapter.Fill(dataTable);

                var rawList = new List<IlcrReportDetailModel>();

                foreach (DataRow row in dataTable.Rows)
                {
                    rawList.Add(new IlcrReportDetailModel
                    {
                        Vin = GetString(row, "VIN", "VinNumber"),
                        Vc = GetString(row, "VC", "VcNumber"),
                        Description = GetString(row, "Description", "VcDescription"),
                        EmmissionType = GetString(row, "EmmissionType", "EmissionType"),
                        Colour = GetString(row, "Colour", "Color"),
                        Model = GetString(row, "Model"),
                        BookingTime = FormatDateTimeValue(GetValue(row, "BookingTime", "Booking Time")),
                        Ilcr = GetString(row, "ILCR"),
                        Age = GetString(row, "Age")
                    });
                }

                // Populate dynamic dropdown option lists
                viewModel.ModelList = rawList.Select(x => x.Model).Where(x => !string.IsNullOrEmpty(x)).Distinct().OrderBy(x => x).ToList();
                viewModel.EmmissionTypeList = rawList.Select(x => x.EmmissionType).Where(x => !string.IsNullOrEmpty(x)).Distinct().OrderBy(x => x).ToList();
                viewModel.IlcrList = rawList.Select(x => x.Ilcr).Where(x => !string.IsNullOrEmpty(x)).Distinct().OrderBy(x => x).ToList();
                viewModel.AgeList = rawList.Select(x => x.Age).Where(x => !string.IsNullOrEmpty(x)).Distinct().OrderBy(x => x).ToList();

                // Apply Filters
                var query = rawList.AsEnumerable();

                if (!string.IsNullOrEmpty(filter.Model) && !filter.Model.Equals("ALL", StringComparison.OrdinalIgnoreCase))
                    query = query.Where(x => string.Equals(x.Model, filter.Model, StringComparison.OrdinalIgnoreCase));

                if (!string.IsNullOrEmpty(filter.EmmissionType) && !filter.EmmissionType.Equals("ALL", StringComparison.OrdinalIgnoreCase))
                    query = query.Where(x => string.Equals(x.EmmissionType, filter.EmmissionType, StringComparison.OrdinalIgnoreCase));

                if (!string.IsNullOrEmpty(filter.Ilcr) && !filter.Ilcr.Equals("ALL", StringComparison.OrdinalIgnoreCase))
                    query = query.Where(x => string.Equals(x.Ilcr, filter.Ilcr, StringComparison.OrdinalIgnoreCase));

                if (!string.IsNullOrEmpty(filter.Age) && !filter.Age.Equals("ALL", StringComparison.OrdinalIgnoreCase))
                    query = query.Where(x => string.Equals(x.Age, filter.Age, StringComparison.OrdinalIgnoreCase));

                int counter = 1;
                foreach (var item in query)
                {
                    item.SrNo = counter++;
                    viewModel.Details.Add(item);
                }
            }
            catch (Exception ex)
            {
                viewModel.ErrorMessage = ex.Message;
            }

            return viewModel;
        }

        private SqlConnection CreateMesDbConnection()
        {
            string? connectionString = _configuration.GetConnectionString("MESDB");
            if (string.IsNullOrWhiteSpace(connectionString))
                throw new InvalidOperationException("The MESDB connection string is missing or empty.");
            return new SqlConnection(connectionString);
        }

        private static object? GetValue(DataRow row, params string[] columnNames)
        {
            DataColumn? matchedColumn = FindColumn(row.Table, columnNames);
            if (matchedColumn == null) return null;
            object value = row[matchedColumn];
            return value == DBNull.Value ? null : value;
        }

        private static string FormatDateTimeValue(object? value)
        {
            if (value == null) return string.Empty;
            if (value is DateTime dateTime) return dateTime.ToString("yyyy-MM-dd HH:mm:ss.fff", CultureInfo.InvariantCulture);
            return Convert.ToString(value, CultureInfo.InvariantCulture) ?? string.Empty;
        }

        private static string GetString(DataRow row, params string[] columnNames)
        {
            object? value = GetValue(row, columnNames);
            return value == null ? string.Empty : Convert.ToString(value, CultureInfo.InvariantCulture)?.Trim() ?? string.Empty;
        }

        private static DataColumn? FindColumn(DataTable table, params string[] columnNames)
        {
            foreach (string expectedColumnName in columnNames)
            {
                DataColumn? matchedColumn = table.Columns.Cast<DataColumn>()
                    .FirstOrDefault(column => string.Equals(column.ColumnName.Trim(), expectedColumnName.Trim(), StringComparison.OrdinalIgnoreCase));
                if (matchedColumn != null) return matchedColumn;
            }
            return null;
        }
    }
}