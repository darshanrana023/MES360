using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using MES360Portal.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace MES360Portal.Repository
{
    public class TcfOemDataReportRepository
    {
        private readonly IConfiguration _configuration;

        public TcfOemDataReportRepository(
            IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public TcfOemDataViewModel GetTcfOemDataReport(
            TcfOemDataFilterModel? filter)
        {
            filter ??= CreateDefaultFilter();

            var viewModel = new TcfOemDataViewModel
            {
                Filter = filter,
                Details = new List<TcfOemDataDetailModel>()
            };

            try
            {
                string shift = NormalizeShift(filter.Shift);
                filter.Shift = shift;

                (DateTime fromDateTime, DateTime toDateTime) =
                    ResolveDateTimeRange(filter, shift);

                viewModel.Details = GetOemData(
                    fromDateTime,
                    toDateTime);
            }
            catch (Exception ex)
            {
                viewModel.ErrorMessage = ex.Message;
            }

            return viewModel;
        }

        private List<TcfOemDataDetailModel> GetOemData(
            DateTime fromDateTime,
            DateTime toDateTime)
        {
            var details = new List<TcfOemDataDetailModel>();

            const string query = @"
SELECT
    Rowid,
    Rowinserttime,
    VIN_Number,
    PIN1_Result,
    PIN2_Result,
    PIN3_Result,
    PIN4_Result
FROM [172.25.68.3].[OEMIntegrationData].[dbo].[TR1_Pedal_Pin_Test]
WHERE Rowinserttime >= @FromDateTime
  AND Rowinserttime < @ToDateTime
ORDER BY Rowinserttime DESC, Rowid DESC;";

            using SqlConnection connection = CreateMesDbConnection();

            using SqlCommand command = new SqlCommand(
                query,
                connection);

            command.CommandType = CommandType.Text;
            command.CommandTimeout = 120;

            command.Parameters.Add(
                "@FromDateTime",
                SqlDbType.DateTime2).Value = fromDateTime;

            command.Parameters.Add(
                "@ToDateTime",
                SqlDbType.DateTime2).Value = toDateTime;

            connection.Open();

            using SqlDataReader reader = command.ExecuteReader();

            int rowIdOrdinal =
                reader.GetOrdinal("Rowid");

            int rowInsertTimeOrdinal =
                reader.GetOrdinal("Rowinserttime");

            int vinNumberOrdinal =
                reader.GetOrdinal("VIN_Number");

            int pin1ResultOrdinal =
                reader.GetOrdinal("PIN1_Result");

            int pin2ResultOrdinal =
                reader.GetOrdinal("PIN2_Result");

            int pin3ResultOrdinal =
                reader.GetOrdinal("PIN3_Result");

            int pin4ResultOrdinal =
                reader.GetOrdinal("PIN4_Result");

            int counter = 1;

            while (reader.Read())
            {
                var item = new TcfOemDataDetailModel
                {
                    SrNo = counter,

                    RowId = GetInt64(
                        reader,
                        rowIdOrdinal),

                    RowInsertTime = GetNullableDateTime(
                        reader,
                        rowInsertTimeOrdinal),

                    VinNumber = GetString(
                        reader,
                        vinNumberOrdinal),

                    Pin1Result = GetNullableInt32(
                        reader,
                        pin1ResultOrdinal),

                    Pin2Result = GetNullableInt32(
                        reader,
                        pin2ResultOrdinal),

                    Pin3Result = GetNullableInt32(
                        reader,
                        pin3ResultOrdinal),

                    Pin4Result = GetNullableInt32(
                        reader,
                        pin4ResultOrdinal)
                };

                details.Add(item);
                counter++;
            }

            return details;
        }

        private static (
            DateTime FromDateTime,
            DateTime ToDateTime)
            ResolveDateTimeRange(
                TcfOemDataFilterModel filter,
                string shift)
        {
            DateTime productionDate =
                filter.FromDate?.Date
                ?? filter.ToDate?.Date
                ?? DateTime.Today;

            switch (shift)
            {
                case "A":
                {
                    DateTime fromDateTime =
                        productionDate
                            .AddHours(6)
                            .AddMinutes(30);

                    DateTime toDateTime =
                        productionDate
                            .AddHours(15);

                    UpdateFilterForShift(
                        filter,
                        productionDate,
                        productionDate,
                        "06",
                        "30",
                        "AM",
                        "03",
                        "00",
                        "PM");

                    return (
                        fromDateTime,
                        toDateTime);
                }

                case "B":
                {
                    DateTime fromDateTime =
                        productionDate
                            .AddHours(15);

                    DateTime toDateTime =
                        productionDate
                            .AddHours(23)
                            .AddMinutes(30);

                    UpdateFilterForShift(
                        filter,
                        productionDate,
                        productionDate,
                        "03",
                        "00",
                        "PM",
                        "11",
                        "30",
                        "PM");

                    return (
                        fromDateTime,
                        toDateTime);
                }

                case "C":
                {
                    DateTime fromDateTime =
                        productionDate
                            .AddHours(23)
                            .AddMinutes(30);

                    DateTime toDateTime =
                        productionDate
                            .AddDays(1)
                            .AddHours(6)
                            .AddMinutes(30);

                    UpdateFilterForShift(
                        filter,
                        productionDate,
                        productionDate.AddDays(1),
                        "11",
                        "30",
                        "PM",
                        "06",
                        "30",
                        "AM");

                    return (
                        fromDateTime,
                        toDateTime);
                }

                case "ALL":
                {
                    DateTime fromDateTime = BuildDateTime(
                        filter.FromDate,
                        filter.FromHour,
                        filter.FromMin,
                        filter.FromAmPm,
                        productionDate
                            .AddHours(6)
                            .AddMinutes(30));

                    DateTime toDateTime = BuildDateTime(
                        filter.ToDate,
                        filter.ToHour,
                        filter.ToMin,
                        filter.ToAmPm,
                        productionDate
                            .AddDays(1)
                            .AddHours(6)
                            .AddMinutes(30));

                    if (toDateTime <= fromDateTime)
                    {
                        throw new ArgumentException(
                            "To Date and Time must be later than From Date and Time.");
                    }

                    return (
                        fromDateTime,
                        toDateTime);
                }

                default:
                    throw new ArgumentException(
                        "Shift must be ALL, A, B, or C.");
            }
        }

        private static DateTime BuildDateTime(
            DateTime? date,
            string? hour,
            string? minute,
            string? amPm,
            DateTime defaultDateTime)
        {
            if (!date.HasValue)
            {
                return defaultDateTime;
            }

            int selectedHour = ParseTimeValue(
                hour,
                "hour",
                1,
                12);

            int selectedMinute = ParseTimeValue(
                minute,
                "minute",
                0,
                59);

            string normalizedAmPm =
                NormalizeAmPm(amPm);

            if (normalizedAmPm == "PM"
                && selectedHour != 12)
            {
                selectedHour += 12;
            }

            if (normalizedAmPm == "AM"
                && selectedHour == 12)
            {
                selectedHour = 0;
            }

            DateTime selectedDate = date.Value.Date;

            return new DateTime(
                selectedDate.Year,
                selectedDate.Month,
                selectedDate.Day,
                selectedHour,
                selectedMinute,
                0);
        }

        private static void UpdateFilterForShift(
            TcfOemDataFilterModel filter,
            DateTime fromDate,
            DateTime toDate,
            string fromHour,
            string fromMinute,
            string fromAmPm,
            string toHour,
            string toMinute,
            string toAmPm)
        {
            filter.FromDate = fromDate;
            filter.FromHour = fromHour;
            filter.FromMin = fromMinute;
            filter.FromAmPm = fromAmPm;

            filter.ToDate = toDate;
            filter.ToHour = toHour;
            filter.ToMin = toMinute;
            filter.ToAmPm = toAmPm;
        }

        private static TcfOemDataFilterModel CreateDefaultFilter()
        {
            return new TcfOemDataFilterModel
            {
                Shift = "ALL",

                FromDate = DateTime.Today,
                FromHour = "06",
                FromMin = "30",
                FromAmPm = "AM",

                ToDate = DateTime.Today.AddDays(1),
                ToHour = "06",
                ToMin = "30",
                ToAmPm = "AM"
            };
        }

        private static string NormalizeShift(
            string? shift)
        {
            string normalized =
                string.IsNullOrWhiteSpace(shift)
                    ? "ALL"
                    : shift.Trim().ToUpperInvariant();

            if (normalized != "ALL"
                && normalized != "A"
                && normalized != "B"
                && normalized != "C")
            {
                throw new ArgumentException(
                    "Shift must be ALL, A, B, or C.");
            }

            return normalized;
        }

        private static string NormalizeAmPm(
            string? amPm)
        {
            string normalized =
                (amPm ?? string.Empty)
                    .Trim()
                    .ToUpperInvariant();

            if (normalized != "AM"
                && normalized != "PM")
            {
                throw new ArgumentException(
                    "AM/PM value must be AM or PM.");
            }

            return normalized;
        }

        private static int ParseTimeValue(
            string? value,
            string fieldName,
            int minimum,
            int maximum)
        {
            if (!int.TryParse(
                value,
                NumberStyles.Integer,
                CultureInfo.InvariantCulture,
                out int result))
            {
                throw new ArgumentException(
                    $"Invalid {fieldName} value.");
            }

            if (result < minimum
                || result > maximum)
            {
                throw new ArgumentOutOfRangeException(
                    fieldName,
                    $"{fieldName} must be between {minimum} and {maximum}.");
            }

            return result;
        }

        private SqlConnection CreateMesDbConnection()
        {
            string? connectionString =
                _configuration.GetConnectionString("MESDB");

            if (string.IsNullOrWhiteSpace(connectionString))
            {
                throw new InvalidOperationException(
                    "The MESDB connection string is missing or empty.");
            }

            return new SqlConnection(connectionString);
        }

        private static long GetInt64(
            SqlDataReader reader,
            int ordinal)
        {
            if (reader.IsDBNull(ordinal))
            {
                return 0;
            }

            object value = reader.GetValue(ordinal);

            return Convert.ToInt64(
                value,
                CultureInfo.InvariantCulture);
        }

        private static int? GetNullableInt32(
            SqlDataReader reader,
            int ordinal)
        {
            if (reader.IsDBNull(ordinal))
            {
                return null;
            }

            object value = reader.GetValue(ordinal);

            if (value is int integerValue)
            {
                return integerValue;
            }

            if (int.TryParse(
                Convert.ToString(
                    value,
                    CultureInfo.InvariantCulture),
                NumberStyles.Integer,
                CultureInfo.InvariantCulture,
                out int parsedValue))
            {
                return parsedValue;
            }

            return null;
        }

        private static DateTime? GetNullableDateTime(
            SqlDataReader reader,
            int ordinal)
        {
            if (reader.IsDBNull(ordinal))
            {
                return null;
            }

            object value = reader.GetValue(ordinal);

            if (value is DateTime dateTime)
            {
                return dateTime;
            }

            if (DateTime.TryParse(
                Convert.ToString(
                    value,
                    CultureInfo.InvariantCulture),
                CultureInfo.InvariantCulture,
                DateTimeStyles.None,
                out DateTime parsedDateTime))
            {
                return parsedDateTime;
            }

            return null;
        }

        private static string GetString(
            SqlDataReader reader,
            int ordinal)
        {
            if (reader.IsDBNull(ordinal))
            {
                return string.Empty;
            }

            return Convert.ToString(
                       reader.GetValue(ordinal),
                       CultureInfo.InvariantCulture)
                   ?.Trim()
                   ?? string.Empty;
        }
    }
}