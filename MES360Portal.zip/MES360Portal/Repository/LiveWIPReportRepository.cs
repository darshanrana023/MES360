using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using MES360Portal.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace MES360Portal.Repository
{
    public class LiveWIPReportRepository
    {
        private readonly IConfiguration _configuration;

        public LiveWIPReportRepository(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public LiveWIPReportViewModel GetLiveWIPReportData()
        {
            var viewModel = new LiveWIPReportViewModel();

            try
            {
                using SqlConnection connection = CreateMesDbConnection();
                using SqlCommand command = new SqlCommand("dbo.sp_LiveWIP_Report", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.CommandTimeout = 120;

                using SqlDataAdapter adapter = new SqlDataAdapter(command);
                var dataTable = new DataTable();
                adapter.Fill(dataTable);

                foreach (DataRow row in dataTable.Rows)
                {
                    var item = new LiveWIPDataModel
                    {
                        Id = GetInt(row, "Id"),
                        VC = GetString(row, "VC"),
                        Model = GetString(row, "Model"),
                        Trim = GetString(row, "Trim"),
                        Colour = GetString(row, "Colour", "Color"),
                        Fuel = GetString(row, "Fuel"),
                        Country = GetString(row, "Country"),
                        BIW = GetInt(row, "BIW"),
                        WBS = GetInt(row, "WBS"),
                        ED_To_Color_Selection = GetInt(row, "ED_To_Color_Selection", "ED_TO_COLOR_SELECTION"),
                        Color_Selections_To_PBS = GetInt(row, "Color_Selections_To_PBS", "COLOR_SELECTIONS_TO_PBS", "Color_Selection_To_PBS"),
                        PBS = GetInt(row, "PBS"),
                        TCF = GetInt(row, "TCF")
                    };

                    viewModel.Details.Add(item);
                }

                viewModel.SummaryCounts = new LiveWIPSummaryModel
                {
                    BIW = viewModel.Details.Sum(x => x.BIW),
                    WBS = viewModel.Details.Sum(x => x.WBS),
                    ED_To_Color_Selection = viewModel.Details.Sum(x => x.ED_To_Color_Selection),
                    Color_Selections_To_PBS = viewModel.Details.Sum(x => x.Color_Selections_To_PBS),
                    PBS = viewModel.Details.Sum(x => x.PBS),
                    TCF = viewModel.Details.Sum(x => x.TCF)
                };
            }
            catch (Exception ex)
            {
                viewModel.ErrorMessage = ex.Message;
            }

            return viewModel;
        }

        private SqlConnection CreateMesDbConnection()
        {
            string? connectionString = _configuration.GetConnectionString("MESDB");
            if (string.IsNullOrWhiteSpace(connectionString))
                throw new InvalidOperationException("The MESDB connection string is missing or empty.");
            return new SqlConnection(connectionString);
        }

        private static string GetString(DataRow row, params string[] columnNames)
        {
            DataColumn? matchedColumn = FindColumn(row.Table, columnNames);
            if (matchedColumn == null) return string.Empty;
            object value = row[matchedColumn];
            return value == DBNull.Value ? string.Empty : Convert.ToString(value, CultureInfo.InvariantCulture)?.Trim() ?? string.Empty;
        }

        private static int GetInt(DataRow row, params string[] columnNames)
        {
            DataColumn? matchedColumn = FindColumn(row.Table, columnNames);
            if (matchedColumn == null) return 0;
            object value = row[matchedColumn];
            if (value == DBNull.Value) return 0;
            if (value is int intVal) return intVal;
            if (int.TryParse(Convert.ToString(value, CultureInfo.InvariantCulture), out int parsedVal)) return parsedVal;
            return 0;
        }

        private static DataColumn? FindColumn(DataTable table, params string[] columnNames)
        {
            foreach (string expectedColumnName in columnNames)
            {
                DataColumn? matchedColumn = table.Columns.Cast<DataColumn>()
                    .FirstOrDefault(column => string.Equals(column.ColumnName.Trim(), expectedColumnName.Trim(), StringComparison.OrdinalIgnoreCase));
                if (matchedColumn != null) return matchedColumn;
            }
            return null;
        }
    }
}