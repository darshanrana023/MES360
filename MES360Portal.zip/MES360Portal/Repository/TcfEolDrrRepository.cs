using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using MES360Portal.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace MES360Portal.Repository
{
    public class TcfEolDrrRepository
    {
        private readonly IConfiguration _configuration;

        public TcfEolDrrRepository(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public TcfEolDrrViewModel GetTcfEolDrrReport(TcfEolDrrFilterModel filter)
        {
            filter ??= new TcfEolDrrFilterModel();

            var viewModel = new TcfEolDrrViewModel
            {
                Filter = filter,
                Details = new List<TcfEolDrrDetailModel>()
            };

            try
            {
                string shift = NormalizeShift(filter.Shift);
                string model = string.IsNullOrWhiteSpace(filter.Model) ? "ALL" : filter.Model.Trim().ToUpperInvariant();
                string station = string.IsNullOrWhiteSpace(filter.Station) ? "CANOPY" : filter.Station.Trim().ToUpperInvariant();

                filter.Shift = shift;
                filter.Model = model;
                filter.Station = station;

                (DateTime startDateTime, DateTime endDateTime) = ResolveDateTimeRange(filter, shift);

                viewModel.Details = GetTcfEolDrrDetails(startDateTime, endDateTime, station, model);
            }
            catch (Exception ex)
            {
                viewModel.ErrorMessage = ex.Message;
            }

            return viewModel;
        }

        private List<TcfEolDrrDetailModel> GetTcfEolDrrDetails(
            DateTime startDateTime,
            DateTime endDateTime,
            string station,
            string model)
        {
            var details = new List<TcfEolDrrDetailModel>();

            using SqlConnection connection = CreateMesDbConnection();
            using SqlCommand command = new SqlCommand("dbo.EOL_DRR_TCf_Fdr_Rahul", connection);

            command.CommandType = CommandType.StoredProcedure;
            command.CommandTimeout = 120;

            command.Parameters.Add("@from", SqlDbType.VarChar, 30).Value = startDateTime.ToString("yyyy-MM-dd HH:mm:ss");
            command.Parameters.Add("@to", SqlDbType.VarChar, 30).Value = endDateTime.ToString("yyyy-MM-dd HH:mm:ss");
            command.Parameters.Add("@Station", SqlDbType.VarChar, 50).Value = station;
            command.Parameters.Add("@model", SqlDbType.VarChar, 50).Value = model;

            using SqlDataAdapter adapter = new SqlDataAdapter(command);
            var dataTable = new DataTable();
            adapter.Fill(dataTable);

            int counter = 1;

            foreach (DataRow row in dataTable.Rows)
            {
                var item = new TcfEolDrrDetailModel
                {
                    SrNo = counter,
                    Id = GetLong(row, "Id"),
                    Date = FormatDate(GetValue(row, "Date")),
                    DRR = GetDecimal(row, "DRR"),
                    NoOfOfflineVehicle = GetInt(row, "No of offline vehicle", "NoOfOfflineVehicle"),
                    TotalVinInspected = GetInt(row, "Total VIN Inspected", "TotalVinInspected"),
                    Target = Convert.ToString(GetValue(row, "Target")) ?? "-"
                };

                details.Add(item);
                counter++;
            }

            return details;
        }

        private static (DateTime StartDateTime, DateTime EndDateTime) ResolveDateTimeRange(
            TcfEolDrrFilterModel filter, string shift)
        {
            if (shift == "ALL")
            {
                DateTime startDateTime = BuildDateTime(filter.FromDate, filter.FromHour, filter.FromMin, filter.FromAmPm);
                DateTime endDateTime = BuildDateTime(filter.ToDate, filter.ToHour, filter.ToMin, filter.ToAmPm);

                if (endDateTime <= startDateTime)
                {
                    throw new ArgumentException("To Date and Time must be later than From Date and Time.");
                }

                return (startDateTime, endDateTime);
            }

            DateTime selectedDate = filter.FromDate?.Date ?? filter.ToDate?.Date ?? DateTime.Today;

            switch (shift)
            {
                case "A":
                    UpdateFilterForShift(filter, selectedDate, selectedDate, "06", "30", "AM", "03", "00", "PM");
                    return (selectedDate.AddHours(6).AddMinutes(30), selectedDate.AddHours(15));
                case "B":
                    UpdateFilterForShift(filter, selectedDate, selectedDate, "03", "00", "PM", "11", "30", "PM");
                    return (selectedDate.AddHours(15), selectedDate.AddHours(23).AddMinutes(30));
                case "C":
                    UpdateFilterForShift(filter, selectedDate, selectedDate.AddDays(1), "11", "30", "PM", "06", "30", "AM");
                    return (selectedDate.AddHours(23).AddMinutes(30), selectedDate.AddDays(1).AddHours(6).AddMinutes(30));
                default:
                    throw new ArgumentException("Shift must be ALL, A, B, or C.");
            }
        }

        private static void UpdateFilterForShift(
            TcfEolDrrFilterModel filter, DateTime fromDate, DateTime toDate,
            string fromHour, string fromMinute, string fromAmPm,
            string toHour, string toMinute, string toAmPm)
        {
            filter.FromDate = fromDate;
            filter.FromHour = fromHour;
            filter.FromMin = fromMinute;
            filter.FromAmPm = fromAmPm;
            filter.ToDate = toDate;
            filter.ToHour = toHour;
            filter.ToMin = toMinute;
            filter.ToAmPm = toAmPm;
        }

        private static DateTime BuildDateTime(DateTime? date, string? hour, string? minute, string? amPm)
        {
            DateTime selectedDate = date?.Date ?? DateTime.Today;
            int selectedHour = ParseTimeValue(hour, "hour", 1, 12);
            int selectedMinute = ParseTimeValue(minute, "minute", 0, 59);
            string normalizedAmPm = NormalizeAmPm(amPm);

            if (normalizedAmPm == "PM" && selectedHour != 12) selectedHour += 12;
            if (normalizedAmPm == "AM" && selectedHour == 12) selectedHour = 0;

            return new DateTime(selectedDate.Year, selectedDate.Month, selectedDate.Day, selectedHour, selectedMinute, 0);
        }

        private static int ParseTimeValue(string? value, string fieldName, int minimum, int maximum)
        {
            if (!int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out int result))
                throw new ArgumentException($"Invalid {fieldName} value.");

            if (result < minimum || result > maximum)
                throw new ArgumentOutOfRangeException(fieldName, $"{fieldName} must be between {minimum} and {maximum}.");

            return result;
        }

        private static string NormalizeAmPm(string? amPm)
        {
            string normalized = (amPm ?? string.Empty).Trim().ToUpperInvariant();
            if (normalized != "AM" && normalized != "PM") throw new ArgumentException("AM/PM value must be AM or PM.");
            return normalized;
        }

        private static string NormalizeShift(string? shift)
        {
            string normalized = string.IsNullOrWhiteSpace(shift) ? "ALL" : shift.Trim().ToUpperInvariant();
            if (normalized != "ALL" && normalized != "A" && normalized != "B" && normalized != "C")
                throw new ArgumentException("Shift must be ALL, A, B, or C.");
            return normalized;
        }

        private SqlConnection CreateMesDbConnection()
        {
            string? connectionString = _configuration.GetConnectionString("MESDB");
            if (string.IsNullOrWhiteSpace(connectionString))
                throw new InvalidOperationException("The MESDB connection string is missing or empty.");
            return new SqlConnection(connectionString);
        }

        private static object? GetValue(DataRow row, params string[] columnNames)
        {
            foreach (string name in columnNames)
            {
                DataColumn? matched = row.Table.Columns.Cast<DataColumn>()
                    .FirstOrDefault(c => string.Equals(c.ColumnName.Trim(), name.Trim(), StringComparison.OrdinalIgnoreCase));
                if (matched != null) return row[matched] == DBNull.Value ? null : row[matched];
            }
            return null;
        }

        private static int GetInt(DataRow row, params string[] columnNames)
        {
            object? value = GetValue(row, columnNames);
            if (value == null) return 0;
            if (value is int integerValue) return integerValue;
            if (int.TryParse(Convert.ToString(value, CultureInfo.InvariantCulture), out int parsedValue)) return parsedValue;
            return 0;
        }

        private static long GetLong(DataRow row, params string[] columnNames)
        {
            object? value = GetValue(row, columnNames);
            if (value == null) return 0;
            if (value is long longValue) return longValue;
            if (long.TryParse(Convert.ToString(value, CultureInfo.InvariantCulture), out long parsedValue)) return parsedValue;
            return 0;
        }

        private static decimal GetDecimal(DataRow row, params string[] columnNames)
        {
            object? value = GetValue(row, columnNames);
            if (value == null) return 0m;
            if (value is decimal decValue) return decValue;
            if (decimal.TryParse(Convert.ToString(value, CultureInfo.InvariantCulture), out decimal parsedValue)) return parsedValue;
            return 0m;
        }

        private static string FormatDate(object? rawVal)
        {
            if (rawVal == null || rawVal == DBNull.Value) return string.Empty;
            if (DateTime.TryParse(rawVal.ToString(), out DateTime dt))
            {
                return dt.ToString("yyyy-MM-dd HH:mm:ss.fff");
            }
            return rawVal.ToString() ?? string.Empty;
        }
    }
}