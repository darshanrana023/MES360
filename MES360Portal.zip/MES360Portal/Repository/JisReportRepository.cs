using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using MES360Portal.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace MES360Portal.Repository
{
    public class JisReportRepository
    {
        private readonly IConfiguration _configuration;

        public JisReportRepository(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public JisReportViewModel GetJisReport()
        {
            var viewModel = new JisReportViewModel
            {
                Details = new List<JisReportDetailModel>()
            };

            try
            {
                using SqlConnection connection = CreateMesDbConnection();
                using SqlCommand command = new SqlCommand("SAN_JISReport", connection);

                command.CommandType = CommandType.StoredProcedure;
                command.CommandTimeout = 120;

                using SqlDataAdapter adapter = new SqlDataAdapter(command);
                var dataTable = new DataTable();
                adapter.Fill(dataTable);

                int counter = 1;

                foreach (DataRow row in dataTable.Rows)
                {
                    var item = new JisReportDetailModel
                    {
                        SrNo = counter,
                        Dsn = GetString(row, "DSN"),
                        Vin = GetString(row, "VIN", "VinNumber"),
                        VcNumber = GetString(row, "VC Number", "VcNumber"),
                        VcDescription = GetString(row, "VC Description", "VcDescription"),
                        VcColor = GetString(row, "VC Color", "VcColor"),
                        CarType = GetString(row, "Car Type", "CarType"),
                        ActualVinGenDate = FormatDateValue(GetValue(row, "Actual Vin Gen Date", "ActualVinGenDate")),
                        ActualVinGenTime = FormatTimeValue(GetValue(row, "Actual Vin Gen Time", "ActualVinGenTime")),
                        Quantity = GetString(row, "Quantity"),
                        PaintedBodyPartNumber = GetString(row, "Painted Body Part Number", "PaintedBodyPartNumber"),
                        EnginePartNumber = GetString(row, "Engine Part Number", "EnginePartNumber"),
                        FuelType = GetString(row, "Fuel Type", "FuelType"),
                        EmissionType = GetString(row, "Emission Type", "EmissionType"),
                        TransmissionType = GetString(row, "Transmission Type", "TransmissionType"),
                        VentilationType = GetString(row, "Ventilation Type", "VentilationType"),
                        TrimLevel = GetString(row, "Trim Level", "TrimLevel"),
                        Location = GetString(row, "Location")
                    };

                    viewModel.Details.Add(item);
                    counter++;
                }
            }
            catch (Exception ex)
            {
                viewModel.ErrorMessage = ex.Message;
            }

            return viewModel;
        }

        private SqlConnection CreateMesDbConnection()
        {
            string? connectionString = _configuration.GetConnectionString("MESDB");
            if (string.IsNullOrWhiteSpace(connectionString))
                throw new InvalidOperationException("The MESDB connection string is missing or empty.");
            return new SqlConnection(connectionString);
        }

        private static object? GetValue(DataRow row, params string[] columnNames)
        {
            DataColumn? matchedColumn = FindColumn(row.Table, columnNames);
            if (matchedColumn == null) return null;
            object value = row[matchedColumn];
            return value == DBNull.Value ? null : value;
        }

        private static string FormatDateValue(object? value)
        {
            if (value == null) return string.Empty;
            if (value is DateTime dateTime) return dateTime.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
            return Convert.ToString(value, CultureInfo.InvariantCulture) ?? string.Empty;
        }

        private static string FormatTimeValue(object? value)
        {
            if (value == null) return string.Empty;
            if (value is DateTime dateTime) return dateTime.ToString("HH:mm:ss.fff", CultureInfo.InvariantCulture);
            return Convert.ToString(value, CultureInfo.InvariantCulture) ?? string.Empty;
        }

        private static string GetString(DataRow row, params string[] columnNames)
        {
            object? value = GetValue(row, columnNames);
            return value == null ? string.Empty : Convert.ToString(value, CultureInfo.InvariantCulture)?.Trim() ?? string.Empty;
        }

        private static DataColumn? FindColumn(DataTable table, params string[] columnNames)
        {
            foreach (string expectedColumnName in columnNames)
            {
                DataColumn? matchedColumn = table.Columns.Cast<DataColumn>()
                    .FirstOrDefault(column => string.Equals(column.ColumnName.Trim(), expectedColumnName.Trim(), StringComparison.OrdinalIgnoreCase));
                if (matchedColumn != null) return matchedColumn;
            }
            return null;
        }
    }
}