using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using MES360Portal.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace MES360Portal.Repository
{
    public class QGWiseTrackingReportRepository
    {
        private readonly IConfiguration _configuration;

        public QGWiseTrackingReportRepository(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public QGWiseTrackingReportViewModel GetReport(string vinNumber)
        {
            var viewModel = new QGWiseTrackingReportViewModel
            {
                VinNumber = vinNumber ?? string.Empty,
                Details = new List<QGWiseTrackingDetailModel>()
            };

            if (string.IsNullOrWhiteSpace(vinNumber))
            {
                return viewModel;
            }

            try
            {
                using SqlConnection connection = CreateMesDbConnection();
                using SqlCommand command = new SqlCommand("QG_WiseTracking", connection);

                command.CommandType = CommandType.StoredProcedure;
                command.CommandTimeout = 120;
                command.Parameters.Add(new SqlParameter("@Serialnumber", SqlDbType.VarChar, 50) { Value = vinNumber.Trim() });

                using SqlDataAdapter adapter = new SqlDataAdapter(command);
                var dataSet = new DataSet();
                adapter.Fill(dataSet);

                // Find the correct data table (handles multi-result set SPs where table 0 is metadata and table 1 is details)
                DataTable? targetTable = null;
                foreach (DataTable table in dataSet.Tables)
                {
                    if (FindColumn(table, "Shop") != null || FindColumn(table, "Station") != null)
                    {
                        targetTable = table;
                        break;
                    }
                }

                // Fallback to first table if specific columns weren't matched
                if (targetTable == null && dataSet.Tables.Count > 0)
                {
                    targetTable = dataSet.Tables[0];
                }

                if (targetTable != null)
                {
                    int counter = 1;
                    foreach (DataRow row in targetTable.Rows)
                    {
                        var item = new QGWiseTrackingDetailModel
                        {
                            SrNo = counter,
                            Shop = GetString(row, "Shop"),
                            Station = GetString(row, "Station"),
                            Date = FormatDateValue(GetValue(row, "Date")),
                            Time = FormatTimeValue(GetValue(row, "Time"))
                        };

                        viewModel.Details.Add(item);
                        counter++;
                    }
                }
            }
            catch (Exception ex)
            {
                viewModel.ErrorMessage = ex.Message;
            }

            return viewModel;
        }

        private SqlConnection CreateMesDbConnection()
        {
            string? connectionString = _configuration.GetConnectionString("MESDB");
            if (string.IsNullOrWhiteSpace(connectionString))
                throw new InvalidOperationException("The MESDB connection string is missing or empty.");
            return new SqlConnection(connectionString);
        }

        private static object? GetValue(DataRow row, params string[] columnNames)
        {
            DataColumn? matchedColumn = FindColumn(row.Table, columnNames);
            if (matchedColumn == null) return null;
            object value = row[matchedColumn];
            return value == DBNull.Value ? null : value;
        }

        private static string FormatDateValue(object? value)
        {
            if (value == null) return string.Empty;
            if (value is DateTime dateTime) return dateTime.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
            return Convert.ToString(value, CultureInfo.InvariantCulture) ?? string.Empty;
        }

        private static string FormatTimeValue(object? value)
        {
            if (value == null) return string.Empty;
            if (value is DateTime dateTime) return dateTime.ToString("HH:mm:ss", CultureInfo.InvariantCulture);
            return Convert.ToString(value, CultureInfo.InvariantCulture) ?? string.Empty;
        }

        private static string GetString(DataRow row, params string[] columnNames)
        {
            object? value = GetValue(row, columnNames);
            return value == null ? string.Empty : Convert.ToString(value, CultureInfo.InvariantCulture)?.Trim() ?? string.Empty;
        }

        private static DataColumn? FindColumn(DataTable table, params string[] columnNames)
        {
            foreach (string expectedColumnName in columnNames)
            {
                DataColumn? matchedColumn = table.Columns.Cast<DataColumn>()
                    .FirstOrDefault(column => string.Equals(column.ColumnName.Trim(), expectedColumnName.Trim(), StringComparison.OrdinalIgnoreCase));
                if (matchedColumn != null) return matchedColumn;
            }
            return null;
        }
    }
}