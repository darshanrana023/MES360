using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using MES360Portal.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace MES360Portal.Repository
{
    public class TcfVinGenerationRepository
    {
        private readonly IConfiguration _configuration;

        public TcfVinGenerationRepository(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public TcfVinGenerationViewModel GetTcfVinGenerationReport(TcfVinGenerationFilterModel filter)
        {
            filter ??= new TcfVinGenerationFilterModel();

            var viewModel = new TcfVinGenerationViewModel
            {
                Filter = filter,
                Details = new List<TcfVinGenerationDetailModel>(),
                ShiftCount = new TcfShiftCountModel()
            };

            try
            {
                viewModel.ShiftCount = GetTcfShiftCounts();

                string shift = NormalizeShift(filter.Shift);
                string model = NormalizeModel(filter.Model);

                filter.Shift = shift;
                filter.Model = model;

                (DateTime fromDateTime, DateTime toDateTime) = ResolveDateTimeRange(filter, shift);

                viewModel.Details = GetTcfVinDetails(
                    fromDateTime,
                    toDateTime,
                    model
                );
            }
            catch (Exception ex)
            {
                viewModel.ErrorMessage = ex.Message;
            }

            return viewModel;
        }

        // TCF IN and TCF Rollout Count pulled from PDSDB
        public TcfShiftCountModel GetTcfShiftCounts()
        {
            var shiftCount = new TcfShiftCountModel();

            try
            {
                using SqlConnection connection = CreatePdsDbConnection();
                using SqlCommand command = new SqlCommand("SAN_TCF_Current_Day_Shift_Count", connection);

                command.CommandType = CommandType.StoredProcedure;
                command.CommandTimeout = 60;

                using SqlDataAdapter adapter = new SqlDataAdapter(command);
                var dataTable = new DataTable();
                adapter.Fill(dataTable);

                if (dataTable.Rows.Count > 0)
                {
                    DataRow row = dataTable.Rows[0];
                    shiftCount.ReportDate = GetString(row, "Report Date", "ReportDate");
                    shiftCount.A_Shift_TCF_IN = GetInt(row, "A Shift TCF IN", "A_Shift_TCF_IN");
                    shiftCount.A_Shift_TCF_Rollout = GetInt(row, "A Shift TCF Rollout", "A_Shift_TCF_Rollout");
                    shiftCount.B_Shift_TCF_IN = GetInt(row, "B Shift TCF IN", "B_Shift_TCF_IN");
                    shiftCount.B_Shift_TCF_Rollout = GetInt(row, "B Shift TCF Rollout", "B_Shift_TCF_Rollout");
                    shiftCount.C_Shift_TCF_IN = GetInt(row, "C Shift TCF IN", "C_Shift_TCF_IN");
                    shiftCount.C_Shift_TCF_Rollout = GetInt(row, "C Shift TCF Rollout", "C_Shift_TCF_Rollout");
                    shiftCount.Total_TCF_IN = GetInt(row, "Total TCF IN", "Total_TCF_IN");
                    shiftCount.Total_TCF_Rollout = GetInt(row, "Total TCF Rollout", "Total_TCF_Rollout");
                }
            }
            catch
            {
                // Fallback to empty model
            }

            return shiftCount;
        }

        // TCF VIN Generation Report Details pulled from MESDB
        private List<TcfVinGenerationDetailModel> GetTcfVinDetails(
            DateTime fromDateTime,
            DateTime toDateTime,
            string model)
        {
            var details = new List<TcfVinGenerationDetailModel>();

            using SqlConnection connection = CreateMesDbConnection();
            using SqlCommand command = new SqlCommand("dbo.SAN_TCF_VIN_Report", connection);

            command.CommandType = CommandType.StoredProcedure;
            command.CommandTimeout = 120;

            command.Parameters.Add("@FromDate", SqlDbType.VarChar, 30).Value = fromDateTime.ToString("yyyy-MM-dd HH:mm:ss");
            command.Parameters.Add("@ToDate", SqlDbType.VarChar, 30).Value = GetStoredProcedureEndDateTime(toDateTime).ToString("yyyy-MM-dd HH:mm:ss");
            
            // Fixed ALL Model issue: Sends "ALL" directly or handles empty string compatibility
            command.Parameters.Add("@Model", SqlDbType.VarChar, 40).Value = string.IsNullOrWhiteSpace(model) ? "ALL" : model;

            using SqlDataAdapter adapter = new SqlDataAdapter(command);
            var dataTable = new DataTable();
            adapter.Fill(dataTable);

            int counter = 1;

            foreach (DataRow row in dataTable.Rows)
            {
                var item = new TcfVinGenerationDetailModel
                {
                    SrNo = counter,
                    OrderNumber = GetString(row, "Order Number", "OrderNumber"),
                    Vin = GetString(row, "VIN", "VinNumber"),
                    VcNumber = GetString(row, "VC Number", "VCNumber"),
                    VcDescription = GetString(row, "VC Description", "VCDescription"),
                    EnginePartNumber = GetString(row, "Engine Part Number", "EnginePartNumber"),
                    VentilationType = GetString(row, "Ventilation Type", "VentilationType"),
                    BiwNumber = GetString(row, "BIW Number", "BIWNumber"),
                    ActualStartDate = FormatDateTimeValue(GetValue(row, "Actual Start Date", "ActualStartDate")),
                    ActualStartTime = FormatDateTimeValue(GetValue(row, "Actual Start Time", "ActualStartTime")),
                    Deleted = GetString(row, "Deleted"),
                    Country = GetString(row, "Country"),
                    HvacPartInfo = GetString(row, "HVAC Part Info", "HvacPartInfo")
                };

                details.Add(item);
                counter++;
            }

            return details;
        }

        private static (DateTime FromDateTime, DateTime ToDateTime) ResolveDateTimeRange(
            TcfVinGenerationFilterModel filter, string shift)
        {
            if (shift == "ALL")
            {
                DateTime fromDateTime = BuildDateTime(filter.FromDate, filter.FromHour, filter.FromMin, filter.FromAmPm, true);
                DateTime toDateTime = BuildDateTime(filter.ToDate, filter.ToHour, filter.ToMin, filter.ToAmPm, false);

                if (toDateTime <= fromDateTime)
                {
                    throw new ArgumentException("To Date and Time must be later than From Date and Time.");
                }

                return (fromDateTime, toDateTime);
            }

            DateTime selectedDate = filter.FromDate?.Date ?? filter.ToDate?.Date ?? DateTime.Today;

            switch (shift)
            {
                case "A":
                    UpdateFilterForShift(filter, selectedDate, selectedDate, "06", "30", "AM", "03", "00", "PM");
                    return (selectedDate.AddHours(6).AddMinutes(30), selectedDate.AddHours(15));
                case "B":
                    UpdateFilterForShift(filter, selectedDate, selectedDate, "03", "00", "PM", "11", "30", "PM");
                    return (selectedDate.AddHours(15), selectedDate.AddHours(23).AddMinutes(30));
                case "C":
                    UpdateFilterForShift(filter, selectedDate, selectedDate.AddDays(1), "11", "30", "PM", "06", "30", "AM");
                    return (selectedDate.AddHours(23).AddMinutes(30), selectedDate.AddDays(1).AddHours(6).AddMinutes(30));
                default:
                    throw new ArgumentException("Shift must be ALL, A, B, or C.");
            }
        }

        private static void UpdateFilterForShift(
            TcfVinGenerationFilterModel filter, DateTime fromDate, DateTime toDate,
            string fromHour, string fromMinute, string fromAmPm,
            string toHour, string toMinute, string toAmPm)
        {
            filter.FromDate = fromDate;
            filter.FromHour = fromHour;
            filter.FromMin = fromMinute;
            filter.FromAmPm = fromAmPm;
            filter.ToDate = toDate;
            filter.ToHour = toHour;
            filter.ToMin = toMinute;
            filter.ToAmPm = toAmPm;
        }

        private static DateTime BuildDateTime(DateTime? date, string? hour, string? minute, string? amPm, bool isFromDate)
        {
            DateTime selectedDate = date?.Date ?? DateTime.Today;
            int selectedHour = ParseTimeValue(hour, "hour", 1, 12);
            int selectedMinute = ParseTimeValue(minute, "minute", 0, 59);
            string normalizedAmPm = NormalizeAmPm(amPm);

            if (normalizedAmPm == "PM" && selectedHour != 12) selectedHour += 12;
            if (normalizedAmPm == "AM" && selectedHour == 12) selectedHour = 0;

            DateTime selectedDateTime = new DateTime(selectedDate.Year, selectedDate.Month, selectedDate.Day, selectedHour, selectedMinute, 0);

            if (!isFromDate)
            {
                selectedDateTime = selectedDateTime.AddMinutes(1);
            }

            return selectedDateTime;
        }

        private static int ParseTimeValue(string? value, string fieldName, int minimum, int maximum)
        {
            if (!int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out int result))
                throw new ArgumentException($"Invalid {fieldName} value.");

            if (result < minimum || result > maximum)
                throw new ArgumentOutOfRangeException(fieldName, $"{fieldName} must be between {minimum} and {maximum}.");

            return result;
        }

        private static string NormalizeAmPm(string? amPm)
        {
            string normalized = (amPm ?? string.Empty).Trim().ToUpperInvariant();
            if (normalized != "AM" && normalized != "PM") throw new ArgumentException("AM/PM value must be AM or PM.");
            return normalized;
        }

        private static string NormalizeShift(string? shift)
        {
            string normalized = string.IsNullOrWhiteSpace(shift) ? "ALL" : shift.Trim().ToUpperInvariant();
            if (normalized != "ALL" && normalized != "A" && normalized != "B" && normalized != "C")
                throw new ArgumentException("Shift must be ALL, A, B, or C.");
            return normalized;
        }

        private static string NormalizeModel(string? model) => string.IsNullOrWhiteSpace(model) ? "ALL" : model.Trim().ToUpperInvariant();

        private SqlConnection CreatePdsDbConnection()
        {
            string? connectionString = _configuration.GetConnectionString("PDSDB");
            if (string.IsNullOrWhiteSpace(connectionString))
                throw new InvalidOperationException("The PDSDB connection string is missing or empty.");
            return new SqlConnection(connectionString);
        }

        private SqlConnection CreateMesDbConnection()
        {
            string? connectionString = _configuration.GetConnectionString("MESDB");
            if (string.IsNullOrWhiteSpace(connectionString))
                throw new InvalidOperationException("The MESDB connection string is missing or empty.");
            return new SqlConnection(connectionString);
        }

        private static DateTime GetStoredProcedureEndDateTime(DateTime exclusiveToDateTime) => exclusiveToDateTime.AddMilliseconds(-1);

        private static object? GetValue(DataRow row, params string[] columnNames)
        {
            DataColumn? matchedColumn = FindColumn(row.Table, columnNames);
            if (matchedColumn == null) return null;
            object value = row[matchedColumn];
            return value == DBNull.Value ? null : value;
        }

        private static string FormatDateTimeValue(object? value)
        {
            if (value == null) return string.Empty;
            if (value is DateTime dateTime) return dateTime.ToString("yyyy-MM-dd HH:mm:ss.fff", CultureInfo.InvariantCulture);
            return Convert.ToString(value, CultureInfo.InvariantCulture) ?? string.Empty;
        }

        private static string GetString(DataRow row, params string[] columnNames)
        {
            object? value = GetValue(row, columnNames);
            return value == null ? string.Empty : Convert.ToString(value, CultureInfo.InvariantCulture)?.Trim() ?? string.Empty;
        }

        private static int GetInt(DataRow row, params string[] columnNames)
        {
            object? value = GetValue(row, columnNames);
            if (value == null) return 0;
            if (value is int integerValue) return integerValue;
            if (int.TryParse(Convert.ToString(value, CultureInfo.InvariantCulture), out int parsedValue)) return parsedValue;
            return 0;
        }

        private static DataColumn? FindColumn(DataTable table, params string[] columnNames)
        {
            foreach (string expectedColumnName in columnNames)
            {
                DataColumn? matchedColumn = table.Columns.Cast<DataColumn>()
                    .FirstOrDefault(column => string.Equals(column.ColumnName.Trim(), expectedColumnName.Trim(), StringComparison.OrdinalIgnoreCase));
                if (matchedColumn != null) return matchedColumn;
            }
            return null;
        }
    }
}