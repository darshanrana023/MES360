using System;
using System.Data;
using MES360Portal.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace MES360Portal.Repository
{
    public class DailyProductionReportRepository
    {
        private readonly IConfiguration _configuration;

        public DailyProductionReportRepository(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public DailyProductionReportViewModel GetDailyProductionReport(DailyProductionFilterModel filter)
        {
            filter ??= new DailyProductionFilterModel();

            var viewModel = new DailyProductionReportViewModel
            {
                Filter = filter,
                ReportData = new DataTable()
            };

            try
            {
                (DateTime fromDateTime, DateTime toDateTime) = ResolveDateTimeRange(filter);

                using SqlConnection connection = CreateMesDbConnection();
                using SqlCommand command = new SqlCommand("Productionreport_daily_Report", connection);

                command.CommandType = CommandType.StoredProcedure;
                command.CommandTimeout = 120;

                command.Parameters.Add("@from", SqlDbType.VarChar, 30).Value = fromDateTime.ToString("yyyy/MM/dd HH:mm:ss.fff");
                command.Parameters.Add("@end", SqlDbType.VarChar, 30).Value = toDateTime.ToString("yyyy/MM/dd HH:mm:ss.fff");
                command.Parameters.Add("@model", SqlDbType.VarChar, 40).Value = "ALL";

                using SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(viewModel.ReportData);
            }
            catch (Exception ex)
            {
                viewModel.ErrorMessage = ex.Message;
            }

            return viewModel;
        }

        private static (DateTime FromDateTime, DateTime ToDateTime) ResolveDateTimeRange(DailyProductionFilterModel filter)
        {
            DateTime fromDateTime = BuildDateTime(filter.FromDate, filter.FromHour, filter.FromMin, filter.FromAmPm, true);
            DateTime toDateTime = BuildDateTime(filter.ToDate, filter.ToHour, filter.ToMin, filter.ToAmPm, false);

            if (toDateTime <= fromDateTime)
            {
                throw new ArgumentException("To Date and Time must be later than From Date and Time.");
            }

            return (fromDateTime, toDateTime);
        }

        private static DateTime BuildDateTime(DateTime? date, string? hour, string? minute, string? amPm, bool isFromDate)
        {
            DateTime selectedDate = date?.Date ?? DateTime.Today;
            int selectedHour = int.TryParse(hour, out var h) ? h : 12;
            int selectedMinute = int.TryParse(minute, out var m) ? m : 0;
            string normalizedAmPm = (amPm ?? "AM").Trim().ToUpperInvariant();

            if (normalizedAmPm == "PM" && selectedHour != 12) selectedHour += 12;
            if (normalizedAmPm == "AM" && selectedHour == 12) selectedHour = 0;

            return new DateTime(selectedDate.Year, selectedDate.Month, selectedDate.Day, selectedHour, selectedMinute, 0);
        }

        private SqlConnection CreateMesDbConnection()
        {
            string? connectionString = _configuration.GetConnectionString("MESDB");
            if (string.IsNullOrWhiteSpace(connectionString))
                throw new InvalidOperationException("The MESDB connection string is missing or empty.");
            return new SqlConnection(connectionString);
        }
    }
}