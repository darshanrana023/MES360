using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using MES360Portal.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace MES360Portal.Repository
{
    public class BiwVinGenerationRepository
    {
        private readonly IConfiguration _configuration;

        public BiwVinGenerationRepository(
            IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public BiwVinGenerationViewModel GetBiwVinGenerationReport(
            BiwVinGenerationFilterModel? filter)
        {
            filter ??= new BiwVinGenerationFilterModel();

            var viewModel = new BiwVinGenerationViewModel
            {
                Filter = filter,
                Details = new List<BiwVinGenerationDetailModel>(),
                ShiftCount = new BiwShiftCountModel()
            };

            try
            {
                viewModel.ShiftCount = GetBiwShiftCounts();

                string shift = NormalizeShift(filter.Shift);
                string model = NormalizeModel(filter.Model);

                filter.Shift = shift;
                filter.Model = model;

                (DateTime fromDateTime, DateTime toDateTime) =
                    ResolveDateTimeRange(filter, shift);

                viewModel.Details = GetBiwVinDetails(
                    filter.VinNumber,
                    fromDateTime,
                    toDateTime,
                    model);
            }
            catch (Exception ex)
            {
                viewModel.ErrorMessage = ex.Message;

                Debug.WriteLine(
                    "BIW VIN Generation report error: " +
                    ex);
            }

            return viewModel;
        }

        public BiwShiftCountModel GetBiwShiftCounts()
        {
            var shiftCount = new BiwShiftCountModel();

            try
            {
                using SqlConnection connection =
                    CreateKmesBiwConnection();

                using SqlCommand command = new SqlCommand(
                    "SAN_BIW_In_Out_Shift_Count",
                    connection);

                command.CommandType =
                    CommandType.StoredProcedure;

                command.CommandTimeout = 60;

                using SqlDataAdapter adapter =
                    new SqlDataAdapter(command);

                var dataTable = new DataTable();

                adapter.Fill(dataTable);

                if (dataTable.Rows.Count > 0)
                {
                    DataRow row = dataTable.Rows[0];

                    shiftCount.ReportDate =
                        GetString(
                            row,
                            "ReportDate",
                            "Report Date");

                    shiftCount.A_Shift_BIW_IN =
                        GetInt(
                            row,
                            "A_Shift_BIW_IN",
                            "A Shift BIW IN");

                    shiftCount.A_Shift_BIW_OUT =
                        GetInt(
                            row,
                            "A_Shift_BIW_OUT",
                            "A Shift BIW OUT");

                    shiftCount.B_Shift_BIW_IN =
                        GetInt(
                            row,
                            "B_Shift_BIW_IN",
                            "B Shift BIW IN");

                    shiftCount.B_Shift_BIW_OUT =
                        GetInt(
                            row,
                            "B_Shift_BIW_OUT",
                            "B Shift BIW OUT");

                    shiftCount.C_Shift_BIW_IN =
                        GetInt(
                            row,
                            "C_Shift_BIW_IN",
                            "C Shift BIW IN");

                    shiftCount.C_Shift_BIW_OUT =
                        GetInt(
                            row,
                            "C_Shift_BIW_OUT",
                            "C Shift BIW OUT");

                    shiftCount.Total_BIW_IN =
                        GetInt(
                            row,
                            "Total_BIW_IN",
                            "Total BIW IN");

                    shiftCount.Total_BIW_OUT =
                        GetInt(
                            row,
                            "Total_BIW_OUT",
                            "Total BIW OUT");
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(
                    "Unable to load BIW shift counts: " +
                    ex.Message);
            }

            return shiftCount;
        }

        private List<BiwVinGenerationDetailModel>
            GetBiwVinDetails(
                string? vinNumber,
                DateTime fromDateTime,
                DateTime toDateTime,
                string model)
        {
            var details =
                new List<BiwVinGenerationDetailModel>();

            using SqlConnection connection =
                CreateConnection();

            using SqlCommand command = new SqlCommand(
                "SAN_BIWVinGeneration",
                connection);

            command.CommandType =
                CommandType.StoredProcedure;

            command.CommandTimeout = 120;

            command.Parameters.Add(
                "@VinNumber",
                SqlDbType.VarChar,
                50).Value =
                    string.IsNullOrWhiteSpace(vinNumber)
                        ? string.Empty
                        : vinNumber.Trim();

            command.Parameters.Add(
                "@start",
                SqlDbType.DateTime).Value =
                    fromDateTime;

            command.Parameters.Add(
                "@end",
                SqlDbType.DateTime).Value =
                    GetStoredProcedureEndDateTime(
                        toDateTime);

            string modelParameter =
                string.IsNullOrWhiteSpace(model) ||
                string.Equals(
                    model,
                    "--Select--",
                    StringComparison.OrdinalIgnoreCase)
                        ? "ALL"
                        : model.Trim();

            command.Parameters.Add(
                "@Model",
                SqlDbType.VarChar,
                40).Value =
                    modelParameter;

            using SqlDataAdapter adapter =
                new SqlDataAdapter(command);

            var dataTable = new DataTable();

            adapter.Fill(dataTable);

            WriteReturnedColumnDiagnostics(dataTable);
            WriteEnginePartDiagnostics(dataTable);

            int counter = 1;

            foreach (DataRow row in dataTable.Rows)
            {
                var item =
                    new BiwVinGenerationDetailModel
                    {
                        SrNo = counter,

                        RowInsertTime =
                            FormatDateTimeValue(
                                GetValue(
                                    row,
                                    "Row InsertTime",
                                    "Row Insert Time",
                                    "RowInsertTime")),

                        TcfVinNumber =
                            GetString(
                                row,
                                "TCF VINumber",
                                "TCFVINNumber",
                                "TCF VIN Number",
                                "TCF VIN No",
                                "TCFVINNo"),

                        VcNumber =
                            GetString(
                                row,
                                "VC Number",
                                "VCNumber",
                                "VC No",
                                "VCNo"),

                        BiwOrderNumber =
                            GetString(
                                row,
                                "BIW OrderNumber",
                                "BIW Order Number",
                                "BIWOrderNumber"),

                        BiwSerialNumber =
                            GetString(
                                row,
                                "BIW SerialNumber",
                                "BIW Serial Number",
                                "BIWSerialNumber"),

                        BiwPartNumber =
                            GetString(
                                row,
                                "BIW PartNumber",
                                "BIW Part Number",
                                "BIWPartNumber"),

                        BiwModel =
                            GetString(
                                row,
                                "BIW Model",
                                "BIWModel"),

                        BiwOrderStartTime =
                            FormatDateTimeValue(
                                GetValue(
                                    row,
                                    "BIW OrderStartTime",
                                    "BIW Order StartTime",
                                    "BIW Order Start Time",
                                    "BIWOrderStartTime")),

                        BiwOrderBookTime =
                            FormatDateTimeValue(
                                GetValue(
                                    row,
                                    "BIW OrderBookTime",
                                    "BIW Order BookTime",
                                    "BIW Order Book Time",
                                    "BIWOrderBookTime")),

                        BiwCqokTime =
                            FormatDateTimeValue(
                                GetValue(
                                    row,
                                    "BIW CQOKTime",
                                    "BIW CQOK Time",
                                    "BIWCQOKTime")),

                        BiwCqokStatus =
                            GetString(
                                row,
                                "BIW CQOk Status",
                                "BIW CQOK Status",
                                "BIWCQOkStatus",
                                "BIWCQOKStatus"),

                        PntOrderNumber =
                            GetString(
                                row,
                                "PNT Order Number",
                                "PNTOrderNumber"),

                        PntSerialNumber =
                            GetString(
                                row,
                                "PNT Serial Number",
                                "PNTSerialNumber"),

                        PntPartNumber =
                            GetString(
                                row,
                                "PNT Part Number",
                                "PNTPartNumber"),

                        PntModel =
                            GetString(
                                row,
                                "PNT Model",
                                "PNTModel"),

                        PntColorName =
                            GetString(
                                row,
                                "PNT Color Name",
                                "PNTColorName"),

                        PntOrderStartTime =
                            FormatDateTimeValue(
                                GetValue(
                                    row,
                                    "PNT Order StartTime",
                                    "PNT Order Start Time",
                                    "PNTOrderStartTime")),

                        PntOrderBookTime =
                            FormatDateTimeValue(
                                GetValue(
                                    row,
                                    "PNT Order BookTime",
                                    "PNT Order Book Time",
                                    "PNTOrderBookTime")),

                        PntCqokTime =
                            FormatDateTimeValue(
                                GetValue(
                                    row,
                                    "PNT CQOK Time",
                                    "PNT CQOKTime",
                                    "PNTCQOKTime")),

                        PntCqaStatus =
                            GetString(
                                row,
                                "PNT CQA Status",
                                "PNTCQAStatus"),

                        BiwVinGenerationTime =
                            FormatDateTimeValue(
                                GetValue(
                                    row,
                                    "BIW VIN GenerationTime",
                                    "BIW VIN Generation Time",
                                    "BIWVINGenerationTime")),

                        TcfVinModel =
                            GetString(
                                row,
                                "TCFVIN Model",
                                "TCF VIN Model",
                                "TCFVINModel"),

                        TcfVinModelRevision =
                            GetString(
                                row,
                                "TCF VIN ModelRevision",
                                "TCF VIN Model Revision",
                                "TCFVINModelRevision"),

                        TcfVinBarrelCode =
                            GetString(
                                row,
                                "TCF VIN BarrelCode",
                                "TCF VIN Barrel Code",
                                "TCFVINBarrelCode"),

                        TcfEmmissionType =
                            GetString(
                                row,
                                "TCF EmmissionType",
                                "TCF Emmission Type",
                                "TCF EmissionType",
                                "TCF Emission Type",
                                "TCFEmmissionType",
                                "TCFEmissionType"),

                        TcfVinGenFormat =
                            GetString(
                                row,
                                "TCF VINGenFormat",
                                "TCF VIN Gen Format",
                                "TCFVINGenFormat"),

                        TcfVinDeleteFlag =
                            GetString(
                                row,
                                "TCF VINDeleteFlag",
                                "TCF VIN Delete Flag",
                                "TCFVINDeleteFlag"),

                        TcfVinPbsColor =
                            GetString(
                                row,
                                "TCF VINPBSColor",
                                "TCF VIN PBS Color",
                                "TCFVINPBSColor"),

                        TcfVinPbsDateTime =
                            FormatDateTimeValue(
                                GetValue(
                                    row,
                                    "TCF VINPBSDateTime",
                                    "TCF VIN PBS DateTime",
                                    "TCF VIN PBS Date Time",
                                    "TCFVINPBSDateTime")),

                        // Important:
                        // Use dedicated flexible column detection.
                        EnginePartNo =
                            GetEnginePartNumber(row)
                    };

                details.Add(item);
                counter++;
            }

            return details;
        }

        private static (
            DateTime FromDateTime,
            DateTime ToDateTime)
            ResolveDateTimeRange(
                BiwVinGenerationFilterModel filter,
                string shift)
        {
            if (shift == "ALL")
            {
                DateTime fromDateTime =
                    BuildDateTime(
                        filter.FromDate,
                        filter.FromHour,
                        filter.FromMin,
                        filter.FromAmPm,
                        true);

                DateTime toDateTime =
                    BuildDateTime(
                        filter.ToDate,
                        filter.ToHour,
                        filter.ToMin,
                        filter.ToAmPm,
                        false);

                if (toDateTime <= fromDateTime)
                {
                    throw new ArgumentException(
                        "To Date and Time must be later " +
                        "than From Date and Time.");
                }

                return (
                    fromDateTime,
                    toDateTime);
            }

            DateTime selectedDate =
                filter.FromDate?.Date
                ?? filter.ToDate?.Date
                ?? DateTime.Today;

            switch (shift)
            {
                case "A":
                    UpdateFilterForShift(
                        filter,
                        selectedDate,
                        selectedDate,
                        "06",
                        "30",
                        "AM",
                        "03",
                        "00",
                        "PM");

                    return (
                        selectedDate
                            .AddHours(6)
                            .AddMinutes(30),
                        selectedDate
                            .AddHours(15));

                case "B":
                    UpdateFilterForShift(
                        filter,
                        selectedDate,
                        selectedDate,
                        "03",
                        "00",
                        "PM",
                        "11",
                        "30",
                        "PM");

                    return (
                        selectedDate
                            .AddHours(15),
                        selectedDate
                            .AddHours(23)
                            .AddMinutes(30));

                case "C":
                    UpdateFilterForShift(
                        filter,
                        selectedDate,
                        selectedDate.AddDays(1),
                        "11",
                        "30",
                        "PM",
                        "06",
                        "30",
                        "AM");

                    return (
                        selectedDate
                            .AddHours(23)
                            .AddMinutes(30),
                        selectedDate
                            .AddDays(1)
                            .AddHours(6)
                            .AddMinutes(30));

                default:
                    throw new ArgumentException(
                        "Shift must be ALL, A, B, or C.");
            }
        }

        private static void UpdateFilterForShift(
            BiwVinGenerationFilterModel filter,
            DateTime fromDate,
            DateTime toDate,
            string fromHour,
            string fromMinute,
            string fromAmPm,
            string toHour,
            string toMinute,
            string toAmPm)
        {
            filter.FromDate = fromDate;
            filter.FromHour = fromHour;
            filter.FromMin = fromMinute;
            filter.FromAmPm = fromAmPm;

            filter.ToDate = toDate;
            filter.ToHour = toHour;
            filter.ToMin = toMinute;
            filter.ToAmPm = toAmPm;
        }

        private static DateTime BuildDateTime(
            DateTime? date,
            string? hour,
            string? minute,
            string? amPm,
            bool isFromDate)
        {
            DateTime selectedDate =
                date?.Date ?? DateTime.Today;

            int selectedHour =
                ParseTimeValue(
                    hour,
                    "hour",
                    1,
                    12);

            int selectedMinute =
                ParseTimeValue(
                    minute,
                    "minute",
                    0,
                    59);

            string normalizedAmPm =
                NormalizeAmPm(amPm);

            if (normalizedAmPm == "PM" &&
                selectedHour != 12)
            {
                selectedHour += 12;
            }

            if (normalizedAmPm == "AM" &&
                selectedHour == 12)
            {
                selectedHour = 0;
            }

            DateTime selectedDateTime =
                new DateTime(
                    selectedDate.Year,
                    selectedDate.Month,
                    selectedDate.Day,
                    selectedHour,
                    selectedMinute,
                    0);

            if (!isFromDate)
            {
                selectedDateTime =
                    selectedDateTime.AddMinutes(1);
            }

            return selectedDateTime;
        }

        private static int ParseTimeValue(
            string? value,
            string fieldName,
            int minimum,
            int maximum)
        {
            if (!int.TryParse(
                value,
                NumberStyles.Integer,
                CultureInfo.InvariantCulture,
                out int result))
            {
                throw new ArgumentException(
                    $"Invalid {fieldName} value.");
            }

            if (result < minimum ||
                result > maximum)
            {
                throw new ArgumentOutOfRangeException(
                    fieldName,
                    $"{fieldName} must be between " +
                    $"{minimum} and {maximum}.");
            }

            return result;
        }

        private static string NormalizeAmPm(
            string? amPm)
        {
            string normalized =
                (amPm ?? string.Empty)
                    .Trim()
                    .ToUpperInvariant();

            if (normalized != "AM" &&
                normalized != "PM")
            {
                throw new ArgumentException(
                    "AM/PM value must be AM or PM.");
            }

            return normalized;
        }

        private static string NormalizeShift(
            string? shift)
        {
            string normalized =
                string.IsNullOrWhiteSpace(shift)
                    ? "ALL"
                    : shift.Trim().ToUpperInvariant();

            if (normalized != "ALL" &&
                normalized != "A" &&
                normalized != "B" &&
                normalized != "C")
            {
                throw new ArgumentException(
                    "Shift must be ALL, A, B, or C.");
            }

            return normalized;
        }

        private static string NormalizeModel(
            string? model)
        {
            return string.IsNullOrWhiteSpace(model)
                ? "ALL"
                : model.Trim().ToUpperInvariant();
        }

        private SqlConnection CreateConnection()
        {
            string? connectionString =
                _configuration.GetConnectionString("MESDB");

            if (string.IsNullOrWhiteSpace(
                connectionString))
            {
                throw new InvalidOperationException(
                    "The MESDB connection string " +
                    "is missing or empty.");
            }

            return new SqlConnection(connectionString);
        }

        private SqlConnection CreateKmesBiwConnection()
        {
            string? connectionString =
                _configuration.GetConnectionString("PDSDB");

            if (string.IsNullOrWhiteSpace(
                connectionString))
            {
                throw new InvalidOperationException(
                    "The PDSDB connection string " +
                    "is missing or empty.");
            }

            return new SqlConnection(connectionString);
        }

        private static DateTime
            GetStoredProcedureEndDateTime(
                DateTime exclusiveToDateTime)
        {
            return exclusiveToDateTime
                .AddMilliseconds(-1);
        }

        private static object? GetValue(
            DataRow row,
            params string[] columnNames)
        {
            DataColumn? matchedColumn =
                FindColumn(
                    row.Table,
                    columnNames);

            if (matchedColumn == null)
            {
                return null;
            }

            object value = row[matchedColumn];

            return value == DBNull.Value
                ? null
                : value;
        }

        private static string FormatDateTimeValue(
            object? value)
        {
            if (value == null)
            {
                return string.Empty;
            }

            if (value is DateTime dateTime)
            {
                return dateTime.ToString(
                    "yyyy-MM-dd HH:mm:ss.fff",
                    CultureInfo.InvariantCulture);
            }

            return Convert.ToString(
                       value,
                       CultureInfo.InvariantCulture)
                   ?? string.Empty;
        }

        private static string GetString(
            DataRow row,
            params string[] columnNames)
        {
            object? value =
                GetValue(
                    row,
                    columnNames);

            return value == null
                ? string.Empty
                : Convert.ToString(
                      value,
                      CultureInfo.InvariantCulture)
                      ?.Trim()
                  ?? string.Empty;
        }

        private static int GetInt(
            DataRow row,
            params string[] columnNames)
        {
            object? value =
                GetValue(
                    row,
                    columnNames);

            if (value == null)
            {
                return 0;
            }

            if (value is int integerValue)
            {
                return integerValue;
            }

            if (int.TryParse(
                Convert.ToString(
                    value,
                    CultureInfo.InvariantCulture),
                NumberStyles.Integer,
                CultureInfo.InvariantCulture,
                out int parsedValue))
            {
                return parsedValue;
            }

            return 0;
        }

        /// <summary>
        /// Finds a returned SQL column after removing spaces,
        /// punctuation, brackets and underscores from both names.
        /// </summary>
        private static DataColumn? FindColumn(
            DataTable table,
            params string[] columnNames)
        {
            if (table == null ||
                columnNames == null ||
                columnNames.Length == 0)
            {
                return null;
            }

            foreach (string expectedColumnName
                in columnNames)
            {
                string normalizedExpectedName =
                    NormalizeColumnName(
                        expectedColumnName);

                DataColumn? matchedColumn =
                    table.Columns
                        .Cast<DataColumn>()
                        .FirstOrDefault(
                            column =>
                                string.Equals(
                                    NormalizeColumnName(
                                        column.ColumnName),
                                    normalizedExpectedName,
                                    StringComparison
                                        .OrdinalIgnoreCase));

                if (matchedColumn != null)
                {
                    return matchedColumn;
                }
            }

            return null;
        }

        /// <summary>
        /// Examples:
        /// [ENGINE PART NO.] becomes ENGINEPARTNO
        /// ENGINE_PART_NO becomes ENGINEPARTNO
        /// Engine Part No becomes ENGINEPARTNO
        /// </summary>
        private static string NormalizeColumnName(
            string? columnName)
        {
            if (string.IsNullOrWhiteSpace(
                columnName))
            {
                return string.Empty;
            }

            return new string(
                columnName
                    .Where(char.IsLetterOrDigit)
                    .Select(char.ToUpperInvariant)
                    .ToArray());
        }

        /// <summary>
        /// Detects and reads Engine Part Number independently
        /// from the exact stored-procedure alias formatting.
        /// </summary>
        private static string GetEnginePartNumber(
            DataRow row)
        {
            if (row == null ||
                row.Table == null)
            {
                return string.Empty;
            }

            string[] supportedNormalizedNames =
            {
                "ENGINEPARTNO",
                "ENGINEPARTNUMBER",
                "ENGINEPARTNUM",
                "ENGINEPN"
            };

            DataColumn? enginePartColumn =
                row.Table.Columns
                    .Cast<DataColumn>()
                    .FirstOrDefault(
                        column =>
                            supportedNormalizedNames.Contains(
                                NormalizeColumnName(
                                    column.ColumnName),
                                StringComparer
                                    .OrdinalIgnoreCase));

            if (enginePartColumn == null)
            {
                return string.Empty;
            }

            object value =
                row[enginePartColumn];

            if (value == null ||
                value == DBNull.Value)
            {
                return string.Empty;
            }

            return Convert.ToString(
                       value,
                       CultureInfo.InvariantCulture)
                   ?.Trim()
                   ?? string.Empty;
        }

        private static void
            WriteReturnedColumnDiagnostics(
                DataTable dataTable)
        {
            Debug.WriteLine(
                "SAN_BIWVinGeneration returned " +
                dataTable.Columns.Count +
                " columns:");

            foreach (DataColumn column
                in dataTable.Columns)
            {
                Debug.WriteLine(
                    "Original column name = [" +
                    column.ColumnName +
                    "], normalized name = [" +
                    NormalizeColumnName(
                        column.ColumnName) +
                    "]");
            }
        }

        private static void WriteEnginePartDiagnostics(
            DataTable dataTable)
        {
            DataColumn? enginePartColumn =
                dataTable.Columns
                    .Cast<DataColumn>()
                    .FirstOrDefault(
                        column =>
                        {
                            string normalizedName =
                                NormalizeColumnName(
                                    column.ColumnName);

                            return
                                normalizedName ==
                                    "ENGINEPARTNO" ||
                                normalizedName ==
                                    "ENGINEPARTNUMBER" ||
                                normalizedName ==
                                    "ENGINEPARTNUM" ||
                                normalizedName ==
                                    "ENGINEPN";
                        });

            if (enginePartColumn == null)
            {
                Debug.WriteLine(
                    "Engine Part Number column was not " +
                    "detected in SAN_BIWVinGeneration.");

                return;
            }

            Debug.WriteLine(
                "Detected Engine Part Number column: [" +
                enginePartColumn.ColumnName +
                "]");

            Debug.WriteLine(
                "Normalized Engine Part Number column: [" +
                NormalizeColumnName(
                    enginePartColumn.ColumnName) +
                "]");

            if (dataTable.Rows.Count == 0)
            {
                Debug.WriteLine(
                    "SAN_BIWVinGeneration returned no rows.");

                return;
            }

            string firstMappedValue =
                GetEnginePartNumber(
                    dataTable.Rows[0]);

            Debug.WriteLine(
                "First mapped Engine Part Number: [" +
                firstMappedValue +
                "]");

            int populatedCount =
                dataTable.Rows
                    .Cast<DataRow>()
                    .Count(
                        row =>
                            !string.IsNullOrWhiteSpace(
                                GetEnginePartNumber(
                                    row)));

            Debug.WriteLine(
                "Populated Engine Part Number rows: " +
                populatedCount +
                " of " +
                dataTable.Rows.Count);
        }
    }
}