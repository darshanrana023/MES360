using System;
using System.Security.Claims;
using Microsoft.AspNetCore.Http;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace MES360Portal.Services
{
    public class UserAccessService
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly string _connectionString;

        public UserAccessService(IHttpContextAccessor httpContextAccessor, IConfiguration configuration)
        {
            _httpContextAccessor = httpContextAccessor;
            _connectionString = configuration.GetConnectionString("PDSDB") 
                ?? throw new InvalidOperationException("PDSDB connection string is missing.");
        }

        public bool HasAccess(string tabName)
        {
            var user = _httpContextAccessor.HttpContext?.User;
            if (user == null || user.Identity == null || !user.Identity.IsAuthenticated)
                return false;

            // Administrators automatically have access to all tabs
            if (user.IsInRole("Admin"))
                return true;

            var userIdStr = user.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (!int.TryParse(userIdStr, out int userId))
                return false;

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                const string query = @"
                    SELECT COUNT(1) 
                    FROM dbo.UserTabAccess 
                    WHERE UserId = @UserId AND TabName = @TabName AND CanAccess = 1";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@UserId", userId);
                    cmd.Parameters.AddWithValue("@TabName", tabName);
                    conn.Open();
                    
                    int count = (int)cmd.ExecuteScalar();
                    return count > 0;
                }
            }
        }
    }
}