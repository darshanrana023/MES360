// MES360 Reporting portal made by Darshan Rana

using MES360Portal.Repository;
using Microsoft.AspNetCore.Authentication.Cookies;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();

builder.Services.AddScoped<TcfNftRepository>();

builder.Services.AddScoped<BiwVinGenerationRepository>();

builder.Services.AddScoped<TcfVinGenerationRepository>();

builder.Services.AddScoped<JisReportRepository>();

builder.Services.AddScoped<LiveWIPReportTestRepository>();

builder.Services.AddScoped<DailyOrderSummaryRepository>();

builder.Services.AddScoped<LiveWIPReportRepository>();

builder.Services.AddScoped<DailyOrderSummaryPartwiseRepository>();

builder.Services.AddScoped<TcfEolDrrRepository>();

builder.Services.AddScoped<IlcrReportRepository>();

builder.Services.AddScoped<OrderInMESRepository>();

builder.Services.AddScoped<DailyProductionReportRepository>();

builder.Services.AddScoped<TcfOemDataReportRepository>();

builder.Services.AddScoped<QGWiseTrackingReportRepository>();
// Add Authentication services
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Account/Login";
        options.ExpireTimeSpan = TimeSpan.FromHours(8);
    });

builder.Services.AddHttpContextAccessor();
builder.Services.AddScoped<MES360Portal.Services.UserAccessService>();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}

app.UseStaticFiles();

app.UseRouting();
app.UseAuthentication();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Account}/{action=Login}/{id?}"); // Points startup to Login page

app.Run();